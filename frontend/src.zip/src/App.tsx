import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { Layout } from "./components/layout/Layout";
import HomePage from "./pages/HomePage";
import CreditFacilityPage from "./pages/CreditPage";
import PolicyPage from "./pages/PolicyPage";
import OrderPage from "./pages/OrderPage";
import CarsPage from "./pages/CarsPage";
import CarDetailPage from "./pages/CarDetailPage";
import AdminPage from "./pages/admin/AdminPage";

function App() {
	return (
		<Router>
			<Layout>
				<Routes>
					<Route path='/' element={<HomePage />} />
					<Route path='/credit-facility' element={<CreditFacilityPage />} />
					<Route path='/policy' element={<PolicyPage />} />
					<Route path='/order' element={<OrderPage />} />
					<Route path='/admin' element={<AdminPage />} />
					<Route path='/cars' element={<CarsPage />} />
					<Route path='/cars/:id' element={<CarDetailPage />} />
				</Routes>
			</Layout>
		</Router>
	);
}

export default App;

// import React from 'react';
// import { Layout } from './components/layout/Layout';
// import HomePage from './pages/HomePage';

// function App() {
//   return (
//     <Layout>
//       <HomePage />
//     </Layout>
//   );
// }

// export default App;
