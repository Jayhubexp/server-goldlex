import React, { useState, useEffect, useRef } from "react";
import { ScrollReveal } from "../animations/ScrollReveal";
import { ChevronLeft, ChevronRight } from "lucide-react";

const testimonials = [
	{
		id: 1,
		name: "Michael Thompson",
		position: "Fleet Manager, TransGlobal Logistics",
		image:
			"https://images.pexels.com/photos/2379005/pexels-photo-2379005.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
		quote:
			"Goldlex Auto & Merchandise Service has been our go-to supplier for fleet maintenance parts for over 5 years. Their quality is unmatched, and their support team always goes above and beyond.",
		rating: 5,
	},
	{
		id: 2,
		name: "Emily Rodriguez",
		position: "Operations Director, AutoCare Services",
		image:
			"https://images.pexels.com/photos/1587009/pexels-photo-1587009.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
		quote:
			"The consistency in quality and delivery has made Goldlex Auto & Merchandise Service an invaluable partner to our auto repair business. They've never let us down, even with our most urgent requests.",
		rating: 5,
	},
	{
		id: 3,
		name: "David Williams",
		position: "Chief Mechanic, Williams Auto Repair",
		image:
			"https://images.pexels.com/photos/1516680/pexels-photo-1516680.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
		quote:
			"As someone who's worked with many suppliers, I can confidently say Goldlex Auto & Merchandise Service provides the best value for money. Their parts last longer and perform better than alternatives.",
		rating: 4,
	},
	{
		id: 4,
		name: "Lisa Chen",
		position: "Procurement Manager, EcoTech Motors",
		image:
			"https://images.pexels.com/photos/1181686/pexels-photo-1181686.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
		quote:
			"What sets Goldlex Auto & Merchandise Service apart is their technical expertise. Their team doesn't just sell parts; they provide solutions that have saved us both time and money.",
		rating: 5,
	},
];

const TestimonialsSection: React.FC = () => {
	const [currentIndex, setCurrentIndex] = useState(0);
	const [isAnimating, setIsAnimating] = useState(false);
	const intervalRef = useRef<NodeJS.Timeout | null>(null);

	const goToNextSlide = () => {
		if (isAnimating) return;

		setIsAnimating(true);
		setCurrentIndex((prevIndex) => (prevIndex + 1) % testimonials.length);

		setTimeout(() => {
			setIsAnimating(false);
		}, 500);
	};

	const goToPrevSlide = () => {
		if (isAnimating) return;

		setIsAnimating(true);
		setCurrentIndex(
			(prevIndex) =>
				(prevIndex - 1 + testimonials.length) % testimonials.length,
		);

		setTimeout(() => {
			setIsAnimating(false);
		}, 500);
	};

	const goToSlide = (index: number) => {
		if (isAnimating || index === currentIndex) return;

		setIsAnimating(true);
		setCurrentIndex(index);

		setTimeout(() => {
			setIsAnimating(false);
		}, 500);
	};

	// Auto-rotate slides
	useEffect(() => {
		const startAutoRotation = () => {
			intervalRef.current = setInterval(() => {
				goToNextSlide();
			}, 8000);
		};

		startAutoRotation();

		return () => {
			if (intervalRef.current) {
				clearInterval(intervalRef.current);
			}
		};
	}, []);

	// Reset interval when manually navigating
	const resetInterval = () => {
		if (intervalRef.current) {
			clearInterval(intervalRef.current);
			intervalRef.current = setInterval(goToNextSlide, 8000);
		}
	};

	const handlePrev = () => {
		goToPrevSlide();
		resetInterval();
	};

	const handleNext = () => {
		goToNextSlide();
		resetInterval();
	};

	return (
		<section id='testimonials' className='py-20 bg-slate-800 text-white'>
			<div className='container mx-auto px-4 md:px-8'>
				<ScrollReveal>
					<div className='text-center mb-16'>
						<span className='inline-block text-emerald-800 font-semibold mb-2'>
							Testimonials
						</span>
						<h2 className='text-3xl md:text-4xl font-bold text-white mb-4'>
							What Our Clients Say
						</h2>
						<p className='max-w-2xl mx-auto text-slate-300'>
							Don't just take our word for it. Hear from businesses who rely on
							our parts every day.
						</p>
						<div className='h-1 w-20 bg-emerald-800 mx-auto mt-6'></div>
					</div>
				</ScrollReveal>

				<ScrollReveal>
					<div className='relative max-w-5xl mx-auto'>
						<div className='overflow-hidden'>
							<div
								className='flex transition-transform duration-500 ease-in-out'
								style={{ transform: `translateX(-${currentIndex * 100}%)` }}>
								{testimonials.map((testimonial) => (
									<div
										key={testimonial.id}
										className='w-full flex-shrink-0 px-4'>
										<div className='bg-slate-700/50 p-8 md:p-10 rounded-xl shadow-xl'>
											<div className='flex flex-col md:flex-row items-center md:items-start gap-6'>
												<div className='flex-shrink-0'>
													<img
														src={testimonial.image}
														alt={testimonial.name}
														className='w-20 h-20 rounded-full object-cover border-4 border-emerald-800'
													/>
												</div>
												<div>
													<div className='flex mb-4'>
														{[...Array(5)].map((_, i) => (
															<svg
																key={i}
																xmlns='http://www.w3.org/2000/svg'
																width='20'
																height='20'
																viewBox='0 0 24 24'
																fill={
																	i < testimonial.rating ? "#F97316" : "none"
																}
																stroke={
																	i < testimonial.rating ? "#F97316" : "#94A3B8"
																}
																strokeWidth='2'
																className='mr-1'>
																<polygon points='12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2'></polygon>
															</svg>
														))}
													</div>
													<p className='text-xl md:text-2xl font-light italic text-slate-100 mb-6'>
														"{testimonial.quote}"
													</p>
													<div>
														<p className='font-semibold text-white'>
															{testimonial.name}
														</p>
														<p className='text-emerald-800'>
															{testimonial.position}
														</p>
													</div>
												</div>
											</div>
										</div>
									</div>
								))}
							</div>
						</div>

						<button
							onClick={handlePrev}
							className='absolute top-1/2 left-0 -translate-y-1/2 bg-emerald-800/80 hover:bg-emerald-800 p-2 rounded-full transition-colors duration-300 transform -translate-x-1/2 focus:outline-none'
							aria-label='Previous testimonial'>
							<ChevronLeft size={24} className='text-white' />
						</button>

						<button
							onClick={handleNext}
							className='absolute top-1/2 right-0 -translate-y-1/2 bg-emerald-800/80 hover:bg-emerald-800 p-2 rounded-full transition-colors duration-300 transform translate-x-1/2 focus:outline-none'
							aria-label='Next testimonial'>
							<ChevronRight size={24} className='text-white' />
						</button>
					</div>

					<div className='flex justify-center mt-8'>
						{testimonials.map((_, index) => (
							<button
								key={index}
								onClick={() => {
									goToSlide(index);
									resetInterval();
								}}
								className={`w-3 h-3 mx-1 rounded-full transition-all duration-300 ${
									currentIndex === index ? "bg-emerald-800 w-8" : "bg-slate-500"
								}`}
								aria-label={`Go to testimonial ${index + 1}`}
							/>
						))}
					</div>
				</ScrollReveal>
			</div>
		</section>
	);
};

export default TestimonialsSection;
