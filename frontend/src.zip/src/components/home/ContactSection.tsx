import React, { useState } from "react";
import { ScrollReveal } from "../animations/ScrollReveal";
import { MapPin, Phone, Mail, Clock, Send } from "lucide-react";

const API_BASE_URL = "https://goldlex-auto-server.onrender.com";

const ContactSection: React.FC = () => {
	// State variables for form inputs
	const [fullName, setFullName] = useState<string>("");
	const [email, setEmail] = useState<string>("");
	const [subject, setSubject] = useState<string>("");
	const [message, setMessage] = useState<string>("");

	// State variables for form submission status and messages
	const [isLoading, setIsLoading] = useState<boolean>(false);
	const [submitMessage, setSubmitMessage] = useState<{
		type: "success" | "error";
		text: string;
	} | null>(null);

	// Function to handle form submission
	const handleSubmit = async (e: React.FormEvent) => {
		e.preventDefault(); // Prevent default browser form submission

		// Clear previous messages
		setSubmitMessage(null);

		// Frontend Validation (mirroring backend's express-validator rules)
		if (!fullName.trim()) {
			setSubmitMessage({ type: "error", text: "Full Name is required." });
			return;
		}
		if (!email.trim()) {
			setSubmitMessage({ type: "error", text: "Email Address is required." });
			return;
		}
		if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
			setSubmitMessage({
				type: "error",
				text: "Please enter a valid email address.",
			});
			return;
		}
		if (!subject.trim()) {
			setSubmitMessage({ type: "error", text: "Subject is required." });
			return;
		}
		if (!message.trim()) {
			setSubmitMessage({ type: "error", text: "Message is required." });
			return;
		}

		setIsLoading(true); // Start loading state

		const formData = {
			fullName,
			email,
			subject,
			message,
		};

		try {
			const response = await fetch(`${API_BASE_URL}/api/contact`, {
				method: "POST",
				headers: {
					"Content-Type": "application/json",
				},
				body: JSON.stringify(formData),
			});

			if (!response.ok) {
				const errorData = await response.json();
				// Display specific validation errors from express-validator or Mongoose
				if (errorData.errors && errorData.errors.length > 0) {
					// express-validator sends errors as an array with 'msg' property
					// Mongoose validation errors might have a 'message' property
					const errorMessages = errorData.errors
						.map((err: any) => err.msg || err.message)
						.join("; ");
					throw new Error(errorMessages);
				}
				throw new Error(errorData.message || "Failed to send message.");
			}

			const result = await response.json();
			setSubmitMessage({
				type: "success",
				text: result.message || "Your message has been sent successfully!",
			});

			// Clear form fields on success
			setFullName("");
			setEmail("");
			setSubject("");
			setMessage("");
		} catch (error: any) {
			console.error("Error submitting contact form:", error);
			setSubmitMessage({
				type: "error",
				text:
					error.message ||
					"An unexpected error occurred while sending your message.",
			});
		} finally {
			setIsLoading(false); // End loading state
		}
	};

	return (
		<section id='contact' className='py-20 bg-white'>
			<div className='container mx-auto px-4 md:px-8'>
				<ScrollReveal>
					<div className='text-center mb-16'>
						<span className='inline-block text-emerald-800 font-semibold mb-2'>
							Contact Us
						</span>
						<h2 className='text-3xl md:text-4xl font-bold text-slate-800 mb-4'>
							Get In Touch
						</h2>
						<p className='max-w-2xl mx-auto text-slate-600'>
							Have questions or need a specific part? Our team is ready to help
							you find exactly what you need.
						</p>
						<div className='h-1 w-20 bg-emerald-800 mx-auto mt-6'></div>
					</div>
				</ScrollReveal>

				<div className='grid grid-cols-1 lg:grid-cols-2 gap-12'>
					<ScrollReveal direction='left'>
						<div className='bg-slate-50 p-8 rounded-xl shadow-lg'>
							<h3 className='text-2xl font-bold text-slate-800 mb-6'>
								Send Us A Message
							</h3>
							<form className='space-y-6' onSubmit={handleSubmit}>
								<div className='grid grid-cols-1 md:grid-cols-2 gap-6'>
									<div>
										<label
											htmlFor='fullName' // Corrected htmlFor to match state
											className='block text-sm font-medium text-slate-700 mb-1'>
											Full Name
										</label>
										<input
											type='text'
											id='fullName' // Corrected id to match state
											className='w-full px-4 py-3 rounded-md border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-800 focus:border-transparent transition-all duration-300'
											placeholder='Your name'
											value={fullName} // Bind to state
											onChange={(e) => setFullName(e.target.value)} // Update state
											required // Add required based on backend validation
										/>
									</div>
									<div>
										<label
											htmlFor='email'
											className='block text-sm font-medium text-slate-700 mb-1'>
											Email Address
										</label>
										<input
											type='email'
											id='email'
											className='w-full px-4 py-3 rounded-md border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-800 focus:border-transparent transition-all duration-300'
											placeholder='your@email.com'
											value={email} // Bind to state
											onChange={(e) => setEmail(e.target.value)} // Update state
											required // Add required based on backend validation
										/>
									</div>
								</div>

								<div>
									<label
										htmlFor='subject'
										className='block text-sm font-medium text-slate-700 mb-1'>
										Subject
									</label>
									<input
										type='text'
										id='subject'
										className='w-full px-4 py-3 rounded-md border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-800 focus:border-transparent transition-all duration-300'
										placeholder='How can we help?'
										value={subject} // Bind to state
										onChange={(e) => setSubject(e.target.value)} // Update state
										required // Add required based on backend validation
									/>
								</div>

								<div>
									<label
										htmlFor='message'
										className='block text-sm font-medium text-slate-700 mb-1'>
										Message
									</label>
									<textarea
										id='message'
										rows={4}
										className='w-full px-4 py-3 rounded-md border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-800 focus:border-transparent transition-all duration-300'
										placeholder='Your message...'
										value={message} // Bind to state
										onChange={(e) => setMessage(e.target.value)} // Update state
										required // Add required based on backend validation
									></textarea>
								</div>

								{/* Submission message display area */}
								{submitMessage && (
									<div
										className={`mt-4 p-3 rounded-md text-sm ${
											submitMessage.type === "success"
												? "bg-green-100 text-green-700"
												: "bg-red-100 text-red-700"
										}`}>
										{submitMessage.text}
									</div>
								)}

								<button
									type='submit'
									className='flex items-center justify-center w-full px-6 py-3 bg-emerald-700 hover:bg-emerald-900 text-white font-semibold rounded-md transition-all duration-300 transform hover:-translate-y-1 hover:shadow-lg'
									disabled={isLoading} // Disable button while loading
								>
									<Send size={18} className='mr-2' />
									{isLoading ? "Sending..." : "Send Message"}
								</button>
							</form>
						</div>
					</ScrollReveal>

					<ScrollReveal direction='right'>
						<div className='h-full flex flex-col'>
							<div className='bg-slate-800 text-white p-8 rounded-xl shadow-lg mb-8'>
								<h3 className='text-2xl font-bold mb-6'>Contact Information</h3>
								<div className='space-y-6'>
									<div className='flex items-start'>
										<MapPin
											size={24}
											className='text-emerald-800 mr-4 mt-1 flex-shrink-0'
										/>
										<div>
											<h4 className='font-semibold mb-1'>Office Location</h4>
											<p className='text-slate-300'>
												Hse No. 328 Cosway Rd. North Legon, Agbogba, Accra
											</p>
										</div>
									</div>

									<div className='flex items-start'>
										<Phone
											size={24}
											className='text-emerald-800 mr-4 mt-1 flex-shrink-0'
										/>
										<div>
											<h4 className='font-semibold mb-1'>Phone Number</h4>
											<p className='text-slate-300'>
												+233204805119 +233500193936
											</p>
										</div>
									</div>

									<div className='flex items-start'>
										<Mail
											size={24}
											className='text-emerald-800 mr-4 mt-1 flex-shrink-0'
										/>
										<div>
											<h4 className='font-semibold mb-1'>Email Address</h4>
											<p className='text-slate-300'>
												goldlexautomerchandise@gmail.com
											</p>
										</div>
									</div>

									<div className='flex items-start'>
										<Clock
											size={24}
											className='text-emerald-800 mr-4 mt-1 flex-shrink-0'
										/>
										<div>
											<h4 className='font-semibold mb-1'>Business Hours</h4>
											<p className='text-slate-300'>
												Monday - Friday: 8:00 AM - 5:00 PM
												<br />
												Saturday: 10:00 AM - 4:00 PM
												<br />
												Sunday: Closed
											</p>
										</div>
									</div>
								</div>
							</div>

							<div className='flex-grow bg-slate-200 rounded-xl overflow-hidden shadow-lg'>
								<iframe
									src='https://maps.app.goo.gl/GAR186DPskSVRYBk7'
									width='100%'
									height='100%'
									style={{ border: 0 }}
									allowFullScreen={true}
									loading='lazy'
									referrerPolicy='no-referrer-when-downgrade'
									title='Goldlex Auto & Merchandise Service Location'></iframe>
							</div>
						</div>
					</ScrollReveal>
				</div>
			</div>
		</section>
	);
};

export default ContactSection;
