import React from "react";
import { ScrollReveal } from "../animations/ScrollReveal";
import { CheckCircle } from "lucide-react";

const AboutSection: React.FC = () => {
	return (
		<section id='about' className='py-20 bg-white'>
			<div className='container mx-auto px-4 md:px-8'>
				<ScrollReveal>
					<div className='text-center mb-16'>
						<span className='inline-block text-emerald-800 font-semibold mb-2'>
							About Us
						</span>
						<h2 className='text-3xl md:text-4xl font-bold text-slate-800 mb-4'>
							Our Story and Mission
						</h2>
						<div className='h-1 w-20 bg-emerald-800 mx-auto'></div>
					</div>
				</ScrollReveal>

				<div className='grid grid-cols-1 md:grid-cols-2 gap-12 items-center'>
					<ScrollReveal direction='left'>
						<div className='relative'>
							<img
								src='/assets/Truck.jpg'
								alt='Goldlex product'
								className='rounded-lg shadow-xl'
							/>
							<div className='absolute -bottom-8 -right-8 bg-emerald-800 p-8 rounded-lg shadow-lg hidden md:block'>
								<p className='text-white font-bold text-4xl'>5+</p>
								<p className='text-white font-medium text-lg'>
									Years Experience
								</p>
							</div>
						</div>
					</ScrollReveal>

					<ScrollReveal direction='right'>
						<div className='space-y-6'>
							<h3 className='text-2xl md:text-3xl font-bold text-slate-800'>
								Quality spare parts for every need.
							</h3>
							<p className='text-slate-600 leading-relaxed'>
								Founded in 2020, Goldlex Auto & Merchandise Service began with a
								simple vision: to provide high-quality, reliable spare parts
								that businesses and individuals can trust. What started as a
								small family business has grown into a leading supplier in the
								industry, without ever compromising our core values.
							</p>
							<p className='text-slate-600 leading-relaxed'>
								Today, we source and supply parts for various industries, from
								automotive to industrial machinery, always maintaining our
								commitment to quality, reliability, and exceptional customer
								service.
							</p>

							<div className='grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4'>
								<div className='flex items-start'>
									<CheckCircle
										className='text-emerald-800 mt-1 mr-2 flex-shrink-0'
										size={20}
									/>
									<span className='text-slate-700'>
										Rigorous quality control
									</span>
								</div>
								<div className='flex items-start'>
									<CheckCircle
										className='text-emerald-800 mt-1 mr-2 flex-shrink-0'
										size={20}
									/>
									<span className='text-slate-700'>
										Trusted supplier network
									</span>
								</div>
								<div className='flex items-start'>
									<CheckCircle
										className='text-emerald-800 mt-1 mr-2 flex-shrink-0'
										size={20}
									/>
									<span className='text-slate-700'>
										Expert technical support
									</span>
								</div>
								<div className='flex items-start'>
									<CheckCircle
										className='text-emerald-800 mt-1 mr-2 flex-shrink-0'
										size={20}
									/>
									<span className='text-slate-700'>
										Fast, reliable shipping
									</span>
								</div>
							</div>

							<div className='pt-4'>
								<a
									href='#services'
									className='inline-block px-6 py-3 bg-slate-800 hover:bg-slate-900 text-white font-medium rounded-md transition-all duration-300'>
									Learn More About Our Services
								</a>
							</div>
						</div>
					</ScrollReveal>
				</div>
			</div>
		</section>
	);
};

export default AboutSection;
