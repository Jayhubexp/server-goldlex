import React, { useRef, useEffect } from "react";
import { ScrollReveal } from "../animations/ScrollReveal";

const timelineEvents = [
	{
		year: "2021",
		title: "Company Founded",
		description:
			"Goldlex Auto & Merchandise Service was established with a focus on selling cars from abroad.",
	},
	{
		year: "2022",
		title: "Expanded Customer Base",
		description:
			"We had an icrease in clients who kept requesting for vehicles that we import.",
	},
	{
		year: "2023",
		title: "Addition of Automobile Spare Parts",
		description:
			"Decided to include the selling of spare parts to complement the sales of cars.",
	},
	{
		year: "2024",
		title: "Requirements Gathering from the Spare Parts Market",
		description:
			"Got in touch with many dealers of the spare parts business in the market and got interested customers.",
	},
	{
		year: "2025",
		title: "First Spare Part Sale",
		description:
			"Made our first business sale in the spare parts market this year.",
	},
	{
		year: "Today",
		title: "Digital Transformation",
		description:
			"Transformed our process of interacting with customers into a digitally seamless way.",
	},
];

const TimelineSection: React.FC = () => {
	const timelineRef = useRef<HTMLDivElement>(null);

	useEffect(() => {
		const handleScroll = () => {
			if (timelineRef.current) {
				const elements = timelineRef.current.querySelectorAll(".timeline-dot");
				const progressLine = timelineRef.current.querySelector(
					".progress-line",
				) as HTMLElement;

				if (elements.length && progressLine) {
					const rect = timelineRef.current.getBoundingClientRect();
					const percentageScrolled = Math.max(
						0,
						Math.min(
							1,
							(window.innerHeight - rect.top) /
								(window.innerHeight + rect.height),
						),
					);

					progressLine.style.height = `${percentageScrolled * 100}%`;

					elements.forEach((dot, index) => {
						const dotElement = dot as HTMLElement;
						const dotPosition = index / (elements.length - 1);

						if (percentageScrolled >= dotPosition - 0.1) {
							dotElement.classList.add("active");
						} else {
							dotElement.classList.remove("active");
						}
					});
				}
			}
		};

		window.addEventListener("scroll", handleScroll);
		handleScroll(); // Initialize on mount

		return () => window.removeEventListener("scroll", handleScroll);
	}, []);

	return (
		<section className='py-20 bg-white'>
			<div className='container mx-auto px-4 md:px-8'>
				<ScrollReveal>
					<div className='text-center mb-16'>
						<span className='inline-block text-emerald-800 font-semibold mb-2'>
							Our Journey
						</span>
						<h2 className='text-3xl md:text-4xl font-bold text-slate-800 mb-4'>
							Milestones That Shaped Us
						</h2>
						<p className='max-w-2xl mx-auto text-slate-600'>
							From our humble beginnings to becoming an industry leader, here's
							a look at our journey of growth, innovation, and excellence.
						</p>
						<div className='h-1 w-20 bg-emerald-800 mx-auto mt-6'></div>
					</div>
				</ScrollReveal>

				<div className='relative' ref={timelineRef}>
					<div className='absolute left-1/2 transform -translate-x-1/2 top-0 bottom-0 w-1 bg-slate-200'>
						<div
							className='progress-line absolute top-0 left-0 right-0 bg-emerald-800 transition-all duration-700 ease-out origin-top'
							style={{ height: "0%" }}></div>
					</div>

					<div className='relative z-10'>
						{timelineEvents.map((event, index) => (
							<div
								key={index}
								className={`flex items-center mb-16 last:mb-0 ${
									index % 2 === 0 ? "flex-row" : "flex-row-reverse"
								} relative`}>
								<div
									className={`w-1/2 ${
										index % 2 === 0 ? "pr-12 text-right" : "pl-12"
									}`}>
									<ScrollReveal
										direction={index % 2 === 0 ? "left" : "right"}
										threshold={0.2}>
										<span className='text-emerald-800 font-bold text-xl mb-2 block'>
											{event.year}
										</span>
										<h3 className='text-xl font-bold text-slate-800 mb-2'>
											{event.title}
										</h3>
										<p className='text-slate-600'>{event.description}</p>
									</ScrollReveal>
								</div>

								<div className='timeline-dot w-6 h-6 bg-white border-4 border-emerald-800 rounded-full absolute left-1/2 transform -translate-x-1/2 z-20 transition-all duration-500'>
									<div className='absolute w-12 h-12 bg-orange-100 rounded-full left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2 scale-0 opacity-0 transition-all duration-500 origin-center'></div>
								</div>

								<div className='w-1/2'></div>
							</div>
						))}
					</div>
				</div>
			</div>

			<style jsx>{`
				.timeline-dot.active {
					background-color: #026913;
				}

				.timeline-dot.active > div {
					transform: translate(-50%, -50%) scale(1);
					opacity: 0.5;
				}
			`}</style>
		</section>
	);
};

export default TimelineSection;
