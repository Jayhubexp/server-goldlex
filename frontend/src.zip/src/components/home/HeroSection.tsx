import React, { useEffect, useRef } from "react";
import { ChevronDown } from "lucide-react";

const HeroSection: React.FC = () => {
	const heroRef = useRef<HTMLDivElement>(null);
	const titleRef = useRef<HTMLHeadingElement>(null);
	const subtitleRef = useRef<HTMLParagraphElement>(null);
	const ctaRef = useRef<HTMLDivElement>(null);

	useEffect(() => {
		const heroElement = heroRef.current;
		const titleElement = titleRef.current;
		const subtitleElement = subtitleRef.current;
		const ctaElement = ctaRef.current;

		if (heroElement && titleElement && subtitleElement && ctaElement) {
			titleElement.style.opacity = "0";
			titleElement.style.transform = "translateY(20px)";
			subtitleElement.style.opacity = "0";
			subtitleElement.style.transform = "translateY(20px)";
			ctaElement.style.opacity = "0";

			// Animate in with sequential timing
			setTimeout(() => {
				titleElement.style.transition =
					"opacity 0.8s ease-out, transform 0.8s ease-out";
				titleElement.style.opacity = "1";
				titleElement.style.transform = "translateY(0)";

				setTimeout(() => {
					subtitleElement.style.transition =
						"opacity 0.8s ease-out, transform 0.8s ease-out";
					subtitleElement.style.opacity = "1";
					subtitleElement.style.transform = "translateY(0)";

					setTimeout(() => {
						ctaElement.style.transition = "opacity 0.8s ease-out";
						ctaElement.style.opacity = "1";
					}, 300);
				}, 200);
			}, 100);
		}

		// Subtle parallax effect on scroll
		const handleScroll = () => {
			if (heroElement) {
				const scrollPosition = window.scrollY;
				heroElement.style.backgroundPositionY = `${scrollPosition * 0.5}px`;
			}
		};

		window.addEventListener("scroll", handleScroll);
		return () => window.removeEventListener("scroll", handleScroll);
	}, []);

	const scrollToAbout = () => {
		const aboutSection = document.getElementById("about");
		if (aboutSection) {
			aboutSection.scrollIntoView({ behavior: "smooth" });
		}
	};

	return (
		<div
			ref={heroRef}
			className='relative h-screen flex items-center justify-center bg-cover bg-center'
			style={{
				backgroundImage:
					'linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.7)), url("/assets/Intro.jpg")',
			}}>
			<div className='container mx-auto px-4 text-center'>
				<h1
					ref={titleRef}
					className='text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6 leading-tight'>
					Precision Engineering{" "}
					<span className='text-emerald-800'>For Every Part</span>
				</h1>
				<p
					ref={subtitleRef}
					className='text-xl md:text-2xl text-white opacity-90 mb-8 max-w-3xl mx-auto leading-relaxed'>
					Your trusted partner for high-quality spare parts with uncompromising
					standards and exceptional service.
				</p>
				<div
					ref={ctaRef}
					className='flex flex-col sm:flex-row gap-4 justify-center'>
					<a
						href='#contact'
						className='px-8 py-3 bg-emerald-800 hover:bg-white-600 text-white font-semibold rounded-md transition-all duration-300 transform hover:-translate-y-1 hover:shadow-lg'>
						Get in Touch
					</a>
					<a
						href='#services'
						className='px-8 py-3 bg-transparent text-white border-2 border-white hover:bg-white/10 font-semibold rounded-md transition-all duration-300 transform hover:-translate-y-1'>
						Explore Services
					</a>
				</div>
			</div>

			<button
				onClick={scrollToAbout}
				className='absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce bg-white/20 hover:bg-white/30 rounded-full p-2 transition-colors duration-300'
				aria-label='Scroll down'>
				<ChevronDown className='text-white' size={24} />
			</button>
		</div>
	);
};

export default HeroSection;
