import React from "react";
import { ScrollReveal } from "../animations/ScrollReveal";
import { Linkedin, Mail, Phone } from "lucide-react";

const teamMembers = [
	{
		name: "Godwin Ayesu",
		position: "Chief Executive Officer",
		image: "/assets/Logo.jpg",
		bio: "With over 5 years in the industry, Godwin leads Goldlex Auto & Merchandise Service with a vision for innovation and quality.",
	},
	{
		name: "Samuel Johnson",
		position: "Head of Operations",
		image: "/assets/Sam.JPG",
		bio: "Samuel ensures our supply chain and operations run smoothly to deliver parts when and where they're needed.",
	},
];

const TeamSection: React.FC = () => {
	return (
		<section id='team' className='py-20 bg-slate-50'>
			<div className='container mx-auto px-4 md:px-8'>
				<ScrollReveal>
					<div className='text-center mb-16'>
						<span className='inline-block text-emerald-800 font-semibold mb-2'>
							Our Team
						</span>
						<h2 className='text-3xl md:text-4xl font-bold text-slate-800 mb-4'>
							Meet The Experts
						</h2>
						<p className='max-w-2xl mx-auto text-slate-600'>
							Our team combines decades of industry experience with a passion
							for quality and customer satisfaction.
						</p>
					</div>
				</ScrollReveal>

				<div className='flex justify-center'>
					<div className='grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 max-w-7xl'>
						{teamMembers.map((member, index) => (
							<ScrollReveal key={index} delay={index * 100}>
								<div className='bg-white rounded-lg overflow-hidden shadow-lg group hover:shadow-xl transition-all duration-300 w-full max-w-xs mx-auto'>
									<div className='relative overflow-hidden'>
										<img
											src={member.image}
											alt={member.name}
											className='w-full h-64 object-cover object-center transition-transform duration-500 group-hover:scale-110'
										/>
										<div className='absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-4 transform translate-y-full group-hover:translate-y-0 transition-transform duration-300'>
											<div className='flex justify-center space-x-3'>
												<a
													href='#'
													className='bg-white/20 hover:bg-white/40 p-2 rounded-full transition-colors duration-300'>
													<Linkedin size={18} className='text-white' />
												</a>
												<a
													href='mailto:goldlexautomerchandise@gmail.com'
													className='bg-white/20 hover:bg-white/40 p-2 rounded-full transition-colors duration-300'>
													<Mail size={18} className='text-white' />
												</a>
												<a
													href='#'
													className='bg-white/20 hover:bg-white/40 p-2 rounded-full transition-colors duration-300'>
													<Phone size={18} className='text-white' />
												</a>
											</div>
										</div>
									</div>
									<div className='p-6'>
										<h3 className='text-xl font-bold text-slate-800 mb-1'>
											{member.name}
										</h3>
										<p className='text-emerald-800 font-medium mb-3'>
											{member.position}
										</p>
										<p className='text-slate-600'>{member.bio}</p>
									</div>
								</div>
							</ScrollReveal>
						))}
					</div>
				</div>
			</div>
		</section>
	);
};

export default TeamSection;
