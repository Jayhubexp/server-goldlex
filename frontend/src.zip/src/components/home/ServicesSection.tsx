import React from "react";
import { ScrollReveal } from "../animations/ScrollReveal";
import {
	ShieldCheck,
	Truck,
	PenTool as Tool,
	Clock,
	Users,
	DollarSign,
} from "lucide-react";
import { ServiceCard } from "../ui/ServiceCard";

const services = [
	{
		icon: <ShieldCheck size={40} className='text-emerald-800' />,
		title: "Quality Assurance",
		description:
			"Every part undergoes rigorous testing and inspection to ensure it meets our high standards before reaching you.",
	},
	{
		icon: <Truck size={40} className='text-emerald-800' />,
		title: "Fast Delivery",
		description:
			"With our extensive logistics network, we ensure your parts arrive quickly and safely, minimizing downtime.",
	},
	{
		icon: <DollarSign size={40} className='text-emerald-800' />,
		title: "Dealer Credit Program",
		description:
			"We make it easier for spare parts dealers to access funds, purchase in bulk, and grow their business without upfront financial pressure.",
	},
	{
		icon: <Tool size={40} className='text-emerald-800' />,
		title: "Expert Consultation",
		description:
			"Our team of specialists provides technical advice to help you find the exact part for your specific requirements.",
	},
	{
		icon: <Clock size={40} className='text-emerald-800' />,
		title: "Extended Warranty",
		description:
			"We stand behind our products with industry-leading warranties and satisfaction guarantees.",
	},
	{
		icon: <Users size={40} className='text-emerald-800' />,
		title: "Customer Support",
		description:
			"Our dedicated support team is available to assist with inquiries, order tracking, and after-sales service.",
	},
];

const ServicesSection: React.FC = () => {
	return (
		<section id='services' className='py-20 bg-slate-50'>
			<div className='container mx-auto px-4 md:px-8'>
				<ScrollReveal>
					<div className='text-center mb-16'>
						<span className='inline-block text-emerald-800 font-semibold mb-2'>
							Our Services
						</span>
						<h2 className='text-3xl md:text-4xl font-bold text-slate-800 mb-4'>
							Why Choose Goldlex Auto & Merchandise Service
						</h2>
						<p className='max-w-2xl mx-auto text-slate-600'>
							We offer premium MCB Bearings along with other high-quality parts
							like Shock Absorbers and Grease. For customers seeking more
							affordable options, we also stock reliable alternatives to suit
							every budget. We're continuously expanding our services, stay
							tuned!
						</p>
						<div className='h-1 w-20 bg-emerald-800 mx-auto mt-6'></div>
					</div>
				</ScrollReveal>

				<div className='grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8'>
					{services.map((service, index) => (
						<ScrollReveal key={index} delay={index * 100}>
							<ServiceCard
								icon={service.icon}
								title={service.title}
								description={service.description}
							/>
						</ScrollReveal>
					))}
				</div>
			</div>
		</section>
	);
};

export default ServicesSection;
