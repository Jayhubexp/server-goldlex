import React, { useState } from "react";
import { ScrollReveal } from "../animations/ScrollReveal";
import { ShoppingCart, Info } from "lucide-react";

const categories = [
	"Engine Parts",
	"Transmission",
	"Suspension",
	"Electrical",
	"Body Parts",
	"All",
];

const partItems = [
	{
		id: 1,
		name: "Premium Brake Pads",
		category: "Suspension",
		image: "/assets/Premium_Bearings.png",
		price: "$45.99",
		rating: 4.8,
	},
	{
		id: 2,
		name: "High-Performance Oil Filter",
		category: "Engine Parts",
		image: "/assets/Premium_Bearings.png",
		price: "$12.99",
		rating: 4.6,
	},
	{
		id: 3,
		name: "LED Headlight Assembly",
		category: "Electrical",
		image: "/assets/Premium_Bearings.png",
		price: "$189.99",
		rating: 4.9,
	},
	{
		id: 4,
		name: "Transmission Gear Set",
		category: "Transmission",
		image: "/assets/Premium_Bearings.png",
		price: "$245.00",
		rating: 4.7,
	},
	{
		id: 5,
		name: "Door Panel Assembly",
		category: "Body Parts",
		image: "/assets/Premium_Bearings.png",
		price: "$199.99",
		rating: 4.5,
	},
	{
		id: 6,
		name: "Performance Spark Plugs (Set)",
		category: "Engine Parts",
		image: "/assets/Premium_Bearings.png",
		price: "$28.99",
		rating: 4.8,
	},
	{
		id: 7,
		name: "Suspension Strut Assembly",
		category: "Suspension",
		image: "/assets/Premium_Bearings.png",
		price: "$135.50",
		rating: 4.7,
	},
	{
		id: 8,
		name: "Alternator - High Output",
		category: "Electrical",
		image: "/assets/Premium_Bearings.png",
		price: "$159.99",
		rating: 4.9,
	},
];

const PartsSection: React.FC = () => {
	const [activeCategory, setActiveCategory] = useState("All");
	const [hoveredPart, setHoveredPart] = useState<number | null>(null);

	const filteredParts =
		activeCategory === "All"
			? partItems
			: partItems.filter((part) => part.category === activeCategory);

	return (
		<section id='parts' className='py-20 bg-white'>
			<div className='container mx-auto px-4 md:px-8'>
				<ScrollReveal>
					<div className='text-center mb-16'>
						<span className='inline-block text-emerald-800 font-semibold mb-2'>
							Our Catalog
						</span>
						<h2 className='text-3xl md:text-4xl font-bold text-slate-800 mb-4'>
							Featured Parts
						</h2>
						<p className='max-w-2xl mx-auto text-slate-600'>
							Browse our selection of high-quality parts, each meeting our
							rigorous standards for durability and performance.
						</p>
						<div className='h-1 w-20 bg-emerald-800 mx-auto mt-6'></div>
					</div>
				</ScrollReveal>

				<ScrollReveal>
					<div className='flex flex-wrap justify-center gap-4 mb-12'>
						{categories.map((category, index) => (
							<button
								key={index}
								className={`px-6 py-2 rounded-full transition-all duration-300 ${
									activeCategory === category
										? "bg-emerald-800 text-white shadow-md"
										: "bg-slate-100 text-slate-700 hover:bg-slate-200"
								}`}
								onClick={() => setActiveCategory(category)}>
								{category}
							</button>
						))}
					</div>
				</ScrollReveal>

				<div className='grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8'>
					{filteredParts.map((part, index) => (
						<ScrollReveal key={part.id} delay={index * 100}>
							<div
								className='bg-white rounded-lg overflow-hidden shadow-md hover:shadow-xl transition-all duration-300 border border-slate-100'
								onMouseEnter={() => setHoveredPart(part.id)}
								onMouseLeave={() => setHoveredPart(null)}>
								<div className='relative overflow-hidden group h-48'>
									<img
										src={part.image}
										alt={part.name}
										className='w-full h-full object-cover transition-transform duration-700 group-hover:scale-110'
									/>
									<div
										className={`absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end justify-between p-4 transform ${
											hoveredPart === part.id ? "opacity-100" : "opacity-0"
										} transition-opacity duration-300`}>
										<div>
											<p className='text-white font-medium'>{part.category}</p>
											<div className='flex items-center mt-1'>
												{[...Array(5)].map((_, i) => (
													<svg
														key={i}
														xmlns='http://www.w3.org/2000/svg'
														width='16'
														height='16'
														viewBox='0 0 24 24'
														fill={
															i < Math.floor(part.rating) ? "#F97316" : "none"
														}
														stroke={
															i < Math.floor(part.rating)
																? "#F97316"
																: "#ffffff"
														}
														strokeWidth='2'
														className='mr-1'>
														<polygon points='12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2'></polygon>
													</svg>
												))}
												<span className='text-white text-sm ml-1'>
													{part.rating}
												</span>
											</div>
										</div>
										<div className='flex items-center gap-2'>
											<button className='p-2 bg-white/20 rounded-full hover:bg-white/40 transition-colors duration-300'>
												<Info size={18} className='text-white' />
											</button>
											<button className='p-2 bg-emerald-800 rounded-full hover:bg-emerald-600 transition-colors duration-300'>
												<ShoppingCart size={18} className='text-white' />
											</button>
										</div>
									</div>
								</div>
								<div className='p-4'>
									<h3 className='font-semibold text-slate-800 text-lg'>
										{part.name}
									</h3>
									<div className='flex justify-between items-center mt-2'>
										<span className='text-emerald-800 font-bold'>
											{part.price}
										</span>
										<span className='text-sm text-slate-500'>In Stock</span>
									</div>
								</div>
							</div>
						</ScrollReveal>
					))}
				</div>

				<div className='text-center mt-12'>
					<a
						href='/order'
						className='inline-block px-8 py-3 bg-slate-800 hover:bg-slate-900 text-white font-medium rounded-md transition-all duration-300'>
						Make an order
					</a>
				</div>
			</div>
		</section>
	);
};

export default PartsSection;
