import React from "react";
import { Link } from "react-router-dom";

interface NavLinkProps {
	href: string;
	children: React.ReactNode;
	isScrolled: boolean;
}

export const NavLink: React.FC<NavLinkProps> = ({
	href,
	children,
	isScrolled,
}) => {
	return (
		<Link
			to={href}
			className={`font-medium transition-all duration-300 hover:text-primary relative after:absolute after:bottom-[-4px] after:left-0 after:h-0.5 after:w-0 after:bg-primary after:transition-all after:duration-300 hover:after:w-full ${
				isScrolled ? "text-secondary" : "text-white"
			}`}>
			{children}
		</Link>
	);
};
