import React from "react";

interface ServiceCardProps {
	icon: React.ReactNode;
	title: string;
	description: string;
}

export const ServiceCard: React.FC<ServiceCardProps> = ({
	icon,
	title,
	description,
}) => {
	return (
		<div className='bg-white p-8 rounded-lg shadow-lg hover:shadow-xl transition-all duration-300 group hover:-translate-y-2 border border-slate-100'>
			<div className='mb-6'>{icon}</div>
			<h3 className='text-xl font-bold text-slate-800 mb-3 group-hover:text-emerald-800 transition-colors duration-300'>
				{title}
			</h3>
			<p className='text-slate-600'>{description}</p>
		</div>
	);
};
