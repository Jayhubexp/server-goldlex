import React from "react";
import {
	Wrench,
	Mail,
	Phone,
	MapPin,
	Clock,
	Facebook,
	Twitter,
	Linkedin,
	Instagram,
} from "lucide-react";

const Footer: React.FC = () => {
	const currentYear = new Date().getFullYear();

	return (
		<footer className='bg-slate-900 text-white pt-16 pb-8'>
			<div className='container mx-auto px-4 md:px-8'>
				<div className='grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12'>
					<div>
						<div className='flex items-center gap-2 mb-4'>
							<Wrench
								size={28}
								className='text-emerald-800'
								strokeWidth={2.5}
							/>
							<span className='font-bold text-xl'>
								Goldlex Auto & Merchandise Service
							</span>
						</div>
						<p className='text-slate-300 mb-4'>
							Your trusted partner for high-quality spare parts with
							uncompromising standards and exceptional service.
						</p>
						<div className='flex space-x-4'>
							<a
								href='#'
								className='text-slate-300 hover:text-emerald-800 transition-colors duration-300'>
								<Facebook size={20} />
							</a>
							<a
								href='#'
								className='text-slate-300 hover:text-emerald-800 transition-colors duration-300'>
								<Twitter size={20} />
							</a>
							<a
								href='#'
								className='text-slate-300 hover:text-emerald-800 transition-colors duration-300'>
								<Linkedin size={20} />
							</a>
							<a
								href='#'
								className='text-slate-300 hover:text-emerald-800 transition-colors duration-300'>
								<Instagram size={20} />
							</a>
						</div>
					</div>

					<div>
						<h3 className='font-semibold text-lg mb-4'>Quick Links</h3>
						<ul className='space-y-2'>
							<li>
								<a
									href='/#about'
									className='text-slate-300 hover:text-emerald-800 transition-colors duration-300'>
									About Us
								</a>
							</li>
							<li>
								<a
									href='/#services'
									className='text-slate-300 hover:text-emerald-800 transition-colors duration-300'>
									Services
								</a>
							</li>
							<li>
								<a
									href='/#parts'
									className='text-slate-300 hover:text-emerald-800 transition-colors duration-300'>
									Parts Catalog
								</a>
							</li>
							<li>
								<a
									href='/#team'
									className='text-slate-300 hover:text-emerald-800 transition-colors duration-300'>
									Our Team
								</a>
							</li>
							<li>
								<a
									href='/#testimonials'
									className='text-slate-300 hover:text-emerald-800 transition-colors duration-300'>
									Testimonials
								</a>
							</li>
							<li>
								<a
									href='/#contact'
									className='text-slate-300 hover:text-emerald-800 transition-colors duration-300'>
									Contact Us
								</a>
							</li>
						</ul>
					</div>

					<div>
						<h3 className='font-semibold text-lg mb-4'>Our Services</h3>
						<ul className='space-y-2'>
							<li>
								<a
									href='#'
									className='text-slate-300 hover:text-emerald-800 transition-colors duration-300'>
									OEM Parts
								</a>
							</li>
							<li>
								<a
									href='#'
									className='text-slate-300 hover:text-emerald-800 transition-colors duration-300'>
									Aftermarket Solutions
								</a>
							</li>
							<li>
								<a
									href='#'
									className='text-slate-300 hover:text-emerald-800 transition-colors duration-300'>
									Custom Parts
								</a>
							</li>
							<li>
								<a
									href='#'
									className='text-slate-300 hover:text-emerald-800 transition-colors duration-300'>
									Quality Testing
								</a>
							</li>
							<li>
								<a
									href='#'
									className='text-slate-300 hover:text-emerald-800 transition-colors duration-300'>
									Expert Consultation
								</a>
							</li>
							<li>
								<a
									href='#'
									className='text-slate-300 hover:text-emerald-800 transition-colors duration-300'>
									Fast Shipping
								</a>
							</li>
						</ul>
					</div>

					<div>
						<h3 className='font-semibold text-lg mb-4'>Contact Info</h3>
						<ul className='space-y-3'>
							<li className='flex items-start'>
								<MapPin size={18} className='mr-2 mt-1 text-emerald-800' />
								<span className='text-slate-300'>
									Hse No. 328 Cosway Rd. North Legon, Agbogba, Accra
								</span>
							</li>
							<li className='flex items-center'>
								<Phone size={18} className='mr-2 text-emerald-800' />
								<span className='text-slate-300'>
									+233204805119 +233500193936
								</span>
							</li>
							<li className='flex items-center'>
								<Mail size={18} className='mr-2 text-emerald-800' />
								<span className='text-slate-300'>
									goldlexautomerchandise@gmail.com
								</span>
							</li>
							<li className='flex items-start'>
								<Clock size={18} className='mr-2 mt-1 text-emerald-800' />
								<span className='text-slate-300'>
									Monday - Friday: 8:00 AM - 5:00 PM
									<br />
									Saturday: 10:00 AM - 4:00 PM
									<br />
									Sunday: Closed
								</span>
							</li>
						</ul>
					</div>
				</div>

				<div className='border-t border-slate-700 pt-8'>
					<div className='flex flex-col md:flex-row justify-between items-center'>
						<p className='text-slate-400 text-sm mb-4 md:mb-0'>
							&copy; {currentYear} Goldlex Auto & Merchandise Service. All
							Rights Reserved.
						</p>
						<div className='flex space-x-4 text-sm text-slate-400'>
							<a
								href='/policy'
								className='hover:text-emerald-800 transition-colors duration-300'>
								Privacy Policy
							</a>
							<a
								href='/policy'
								className='hover:text-emerald-800 transition-colors duration-300'>
								Terms of Service
							</a>
							<a
								href='#'
								className='hover:text-emerald-800 transition-colors duration-300'>
								Sitemap
							</a>
						</div>
					</div>
				</div>
			</div>
		</footer>
	);
};

export default Footer;
