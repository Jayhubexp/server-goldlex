import React, { useState, useEffect } from "react";
import { Wrench } from "lucide-react";
import { NavLink } from "../ui/NavLink";
import { Link } from "react-router-dom";

const Header: React.FC = () => {
	const [isScrolled, setIsScrolled] = useState(false);
	const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

	useEffect(() => {
		const handleScroll = () => {
			setIsScrolled(window.scrollY > 20);
		};

		window.addEventListener("scroll", handleScroll);
		return () => window.removeEventListener("scroll", handleScroll);
	}, []);

	const toggleMobileMenu = () => {
		setIsMobileMenuOpen(!isMobileMenuOpen);
	};

	return (
		<header
			className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
				isScrolled
					? "bg-white/90 backdrop-blur-sm shadow-md py-3"
					: "bg-emerald-800 py-5"
			}`}>
			<div className='container mx-auto px-4 md:px-8'>
				<div className='flex items-center justify-between'>
					<Link to='/' className='flex items-center gap-2'>
						<Wrench
							size={32}
							className={`${
								isScrolled ? "text-primary" : "text-white"
							} transition-colors duration-300`}
							strokeWidth={2.5}
						/>
						<span
							className={`font-bold text-xl md:text-2xl transition-colors duration-300 ${
								isScrolled ? "text-secondary" : "text-white"
							}`}>
							Goldlex Auto & Merchandise Service
						</span>
					</Link>

					<nav className='hidden lg:flex items-center gap-8'>
						<NavLink href='/' isScrolled={isScrolled}>
							Home
						</NavLink>
						<NavLink href='/cars' isScrolled={isScrolled}>
							Cars
						</NavLink>
						<NavLink href='/credit-facility' isScrolled={isScrolled}>
							Credit Facility
						</NavLink>
						<NavLink href='/order' isScrolled={isScrolled}>
							Order Parts
						</NavLink>
						<NavLink href='/policy' isScrolled={isScrolled}>
							Policy
						</NavLink>
					</nav>

					<button
						onClick={toggleMobileMenu}
						className='lg:hidden p-2 rounded-md'
						aria-label='Toggle menu'>
						<div
							className={`w-6 h-0.5 mb-1.5 transition-all duration-300 ${
								isScrolled ? "bg-secondary" : "bg-white"
							} ${
								isMobileMenuOpen ? "transform rotate-45 translate-y-2" : ""
							}`}></div>
						<div
							className={`w-6 h-0.5 mb-1.5 transition-all duration-300 ${
								isScrolled ? "bg-secondary" : "bg-white"
							} ${isMobileMenuOpen ? "opacity-0" : ""}`}></div>
						<div
							className={`w-6 h-0.5 transition-all duration-300 ${
								isScrolled ? "bg-secondary" : "bg-white"
							} ${
								isMobileMenuOpen ? "transform -rotate-45 -translate-y-2" : ""
							}`}></div>
					</button>
				</div>

				<div
					className={`lg:hidden absolute left-0 right-0 bg-white shadow-md transition-all duration-300 overflow-hidden ${
						isMobileMenuOpen ? "max-h-screen py-4" : "max-h-0"
					}`}>
					<div className='container mx-auto px-4'>
						<div className='flex flex-col space-y-3'>
							<Link
								to='/'
								className='py-2 text-secondary font-medium'
								onClick={() => setIsMobileMenuOpen(false)}>
								Home
							</Link>
							<Link
								to='/cars'
								className='py-2 text-secondary font-medium'
								onClick={() => setIsMobileMenuOpen(false)}>
								Cars
							</Link>
							<Link
								to='/credit-facility'
								className='py-2 text-secondary font-medium'
								onClick={() => setIsMobileMenuOpen(false)}>
								Credit Facility
							</Link>
							<Link
								to='/order'
								className='py-2 text-secondary font-medium'
								onClick={() => setIsMobileMenuOpen(false)}>
								Order Parts
							</Link>
							<Link
								to='/policy'
								className='py-2 text-secondary font-medium'
								onClick={() => setIsMobileMenuOpen(false)}>
								Policy
							</Link>
						</div>
					</div>
				</div>
			</div>
		</header>
	);
};

export default Header;
// import React, { useState, useEffect } from "react";
// import { Wrench } from "lucide-react";
// import { NavLink } from "../ui/NavLink";

// const Header: React.FC = () => {
// 	const [isScrolled, setIsScrolled] = useState(false);
// 	const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

// 	useEffect(() => {
// 		const handleScroll = () => {
// 			setIsScrolled(window.scrollY > 20);
// 		};

// 		window.addEventListener("scroll", handleScroll);
// 		return () => window.removeEventListener("scroll", handleScroll);
// 	}, []);

// 	const toggleMobileMenu = () => {
// 		setIsMobileMenuOpen(!isMobileMenuOpen);
// 	};

// 	return (
// 		<header
// 			className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
// 				isScrolled
// 					? "bg-white/90 backdrop-blur-sm shadow-md py-3"
// 					: "bg-transparent py-5"
// 			}`}>
// 			<div className='container mx-auto px-4 md:px-8'>
// 				<div className='flex items-center justify-between'>
// 					<a href='#' className='flex items-center gap-2'>
// 						<Wrench
// 							size={32}
// 							className={`${
// 								isScrolled ? "text-emerald-800" : "text-white"
// 							} transition-colors duration-300`}
// 							strokeWidth={2.5}
// 						/>
// 						<span
// 							className={`font-bold text-xl md:text-2xl transition-colors duration-300 ${
// 								isScrolled ? "text-slate-800" : "text-white"
// 							}`}>
// 							Goldlex Auto & Merchandise Service
// 						</span>
// 					</a>

// 					{/* Desktop Navigation */}
// 					<nav className='hidden lg:flex items-center gap-8'>
// 						<NavLink href='#about' isScrolled={isScrolled}>
// 							About
// 						</NavLink>
// 						<NavLink href='#services' isScrolled={isScrolled}>
// 							Services
// 						</NavLink>
// 						<NavLink href='#team' isScrolled={isScrolled}>
// 							Team
// 						</NavLink>
// 						<NavLink href='#parts' isScrolled={isScrolled}>
// 							Parts
// 						</NavLink>
// 						<NavLink href='#testimonials' isScrolled={isScrolled}>
// 							Testimonials
// 						</NavLink>
// 						<NavLink href='#contact' isScrolled={isScrolled}>
// 							Contact
// 						</NavLink>
// 					</nav>

// 					{/* Mobile Menu Button */}
// 					<button
// 						onClick={toggleMobileMenu}
// 						className='lg:hidden p-2 rounded-md'
// 						aria-label='Toggle menu'>
// 						<div
// 							className={`w-6 h-0.5 mb-1.5 transition-all duration-300 ${
// 								isScrolled ? "bg-slate-800" : "bg-white"
// 							} ${
// 								isMobileMenuOpen ? "transform rotate-45 translate-y-2" : ""
// 							}`}></div>
// 						<div
// 							className={`w-6 h-0.5 mb-1.5 transition-all duration-300 ${
// 								isScrolled ? "bg-slate-800" : "bg-white"
// 							} ${isMobileMenuOpen ? "opacity-0" : ""}`}></div>
// 						<div
// 							className={`w-6 h-0.5 transition-all duration-300 ${
// 								isScrolled ? "bg-slate-800" : "bg-white"
// 							} ${
// 								isMobileMenuOpen ? "transform -rotate-45 -translate-y-2" : ""
// 							}`}></div>
// 					</button>
// 				</div>

// 				{/* Mobile Menu */}
// 				<div
// 					className={`lg:hidden absolute left-0 right-0 bg-white shadow-md transition-all duration-300 overflow-hidden ${
// 						isMobileMenuOpen ? "max-h-screen py-4" : "max-h-0"
// 					}`}>
// 					<div className='container mx-auto px-4'>
// 						<div className='flex flex-col space-y-3'>
// 							<a
// 								href='#about'
// 								className='py-2 text-slate-800 font-medium'
// 								onClick={() => setIsMobileMenuOpen(false)}>
// 								About
// 							</a>
// 							<a
// 								href='#services'
// 								className='py-2 text-slate-800 font-medium'
// 								onClick={() => setIsMobileMenuOpen(false)}>
// 								Services
// 							</a>
// 							<a
// 								href='#team'
// 								className='py-2 text-slate-800 font-medium'
// 								onClick={() => setIsMobileMenuOpen(false)}>
// 								Team
// 							</a>
// 							<a
// 								href='#parts'
// 								className='py-2 text-slate-800 font-medium'
// 								onClick={() => setIsMobileMenuOpen(false)}>
// 								Parts
// 							</a>
// 							<a
// 								href='#testimonials'
// 								className='py-2 text-slate-800 font-medium'
// 								onClick={() => setIsMobileMenuOpen(false)}>
// 								Testimonials
// 							</a>
// 							<a
// 								href='#contact'
// 								className='py-2 text-slate-800 font-medium'
// 								onClick={() => setIsMobileMenuOpen(false)}>
// 								Contact
// 							</a>
// 						</div>
// 					</div>
// 				</div>
// 			</div>
// 		</header>
// 	);
// };

// export default Header;
