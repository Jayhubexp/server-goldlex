export interface Car {
	id: number;
	title: string;
	make: string;
	model: string;
	year: number;
	price: number;
	mileage: number;
	status: "available" | "sold";
	images: string[];
	specifications: {
		engine: string;
		transmission: string;
		fuelType: string;
		color: string;
		doors: number;
		seats: number;
		drivetrain: string;
		vin: string;
		features: string[];
	};
	description: string;
}

export const carsData: Car[] = [
	{
		id: 1,
		title: "2018 Hyundai Santa Fe",
		make: "Hyundai",
		model: "Santa Fe",
		year: 2018,
		price: 9000,
		mileage: 104000,
		status: "available",
		images: [
			"/assets/Hyundai1_1.jpg",
			"/assets/Hyundai1_2.jpg",
			"/assets/Hyundai1_3.jpg",
			"/assets/Hyundai1_4.jpg",
		],
		specifications: {
			engine: "2.4L/V4",
			transmission: "CVT Automatic",
			fuelType: "Gasoline",
			color: "Silver Metallic",
			doors: 4,
			seats: 5,
			drivetrain: "Front-Wheel Drive",
			vin: "2T1BURHE5MC123456",
			features: [
				"Hyundai Safety Sense 2.0",
				"Apple CarPlay/Android Auto",
				"Backup Camera",
				"Bluetooth Connectivity",
				"Automatic Climate Control",
				"LED Headlights",
			],
		},
		description:
			"This 2018 Hyundai Santa Fe is in excellent condition with low mileage. Perfect for daily commuting with outstanding fuel efficiency and reliability.",
	},
	{
		id: 2,
		title: "Hyundai Santa Fe 2018",
		make: "Hyundai",
		model: "Santa Fe",
		year: 2018,
		price: 10400,
		mileage: 71000,
		status: "available",
		images: [
			"/assets/Hyundai2_1.jpg",
			"/assets/Hyundai2_2.jpg",
			"/assets/Hyundai2_3.jpg",
		],
		specifications: {
			engine: "2.4L/V4",
			transmission: "CVT Automatic",
			fuelType: "Gasoline",
			color: "Oxford White",
			doors: 4,
			seats: 5,
			drivetrain: "Front-Wheel Drive",
			vin: "19XFC2F59KE123456",
			features: [
				"Hyundai Sensing Suite",
				"Apple CarPlay/Android Auto",
				"Multi-Angle Rearview Camera",
				"Remote Engine Start",
				"Dual-Zone Climate Control",
				"LED Daytime Running Lights",
			],
		},
		description:
			"Well-maintained 2018 Hyundai Santa Fe with modern features and excellent fuel economy. Great for both city driving and highway cruising.",
	},
	{
		id: 3,
		title: "Hyundai Santa Fe 2016",
		make: "Hyundai",
		model: "2016 Santa Fe",
		year: 2016,
		price: 10700,
		mileage: 150000,
		status: "available",
		images: [
			"/assets/Hyundai3_1.jpg",
			"/assets/Hyundai3_2.jpg",
			"/assets/Hyundai3_3.jpg",
		],
		specifications: {
			engine: "3.3L/ V6",
			transmission: "8-Speed Automatic",
			fuelType: "Gasoline",
			color: "Metallic Silver",
			doors: 4,
			seats: 5,
			drivetrain: "4-Wheel Drive",
			vin: "WBA5R1C50KA123456",
			features: [
				"Hyundai",
				"Premium Sound System",
				"Leather Upholstery",
				"Sunroof",
				"Navigation System",
				"Adaptive Cruise Control",
				"Parking Sensors",
			],
		},
		description:
			"Luxury meets performance in this 2016 Hyundai SantaFe. Features premium interior, advanced technology, and a great driving experience.",
	},
	{
		id: 4,
		title: "Hyundai Santa Fe 2016",
		make: "Hyundai",
		model: "2016 Santa Fe",
		year: 2016,
		price: 9800,
		mileage: 250000,
		status: "available",
		images: [
			"/assets/Hyundai4_1.jpg",
			"/assets/Hyundai4_2.jpg",
			"/assets/Hyundai4_3.jpg",
			"/assets/Hyundai4_4.jpg",
		],
		specifications: {
			engine: "2.4L/V4",
			transmission: "10-Speed Automatic",
			fuelType: "Gasoline",
			color: "Jet Black",
			doors: 4,
			seats: 5,
			drivetrain: "4WD",
			vin: "1FTEW1E50JF123456",
			features: [
				"SYNC 3 Infotainment",
				"Trailer Tow Package",
				"Bed Liner",
				"Running Boards",
				"Backup Camera",
				"Cruise Control",
			],
		},
		description:
			"Powerful and versatile 2016 Hyundai SantaFe with excellent towing capacity. Perfect for family and team trips.",
	},
	{
		id: 5,
		title: "2024 Nissan Rogue",
		make: "Nissan",
		model: "Rogue",
		year: 2024,
		price: 18200,
		mileage: 18000,
		status: "available",
		images: [
			"/assets/NISSAN_ROGUE_1.jpg",
			"/assets/NISSAN_ROGUE_2.jpg",
			"/assets/NISSAN_ROGUE_3.jpg",
			"/assets/NISSAN_ROGUE_4.jpg",
			"/assets/NISSAN_ROGUE_5.jpg",
		],
		specifications: {
			engine: "1.5L / V3",
			transmission: "CVT Automatic",
			fuelType: "Gasoline",
			color: "Gray Metallic",
			doors: 4,
			seats: 5,
			drivetrain: "Front-Wheel Drive",
			vin: "1N4AL3AP8HC123456",
			features: [
				"NissanConnect Infotainment",
				"Bluetooth Connectivity",
				"Backup Camera",
				"Push Button Start",
				"Automatic Climate Control",
			],
		},
		description:
			"Reliable and fuel-efficient 2024 Nissan Rogue. Great value for money with comfortable interior and smooth ride quality.",
	},
	{
		id: 6,
		title: "2024 Nissan Rogue",
		make: "Nissan",
		model: "Rogue",
		year: 2024,
		price: 16700,
		mileage: 18000,
		status: "available",
		images: [
			"/assets/n_1.jpg",
			"/assets/n_2.jpg",
			"/assets/n_3.jpg",
			"/assets/n_4.jpg",
		],
		specifications: {
			engine: "1.5L V3",
			transmission: "CVT Automatic",
			fuelType: "Gasoline",
			color: "Everest White TriCoat",
			doors: 4,
			seats: 5,
			drivetrain: "Front-Wheel Drive",
			vin: "1N4AL3AP8HC123456",
			features: [
				"NissanConnect Infotainment",
				"Bluetooth Connectivity",
				"Backup Camera",
				"Push Button Start",
				"Automatic Climate Control",
			],
		},
		description:
			"Reliable and fuel-efficient 2024 Nissan Rogue. Great value for money with comfortable interior and smooth ride quality.",
	},
	{
		id: 7,
		title: "2017 Mitsubishi Outlander",
		make: "Mitsubishi",
		model: "Outlander",
		year: 2017,
		price: 7000,
		mileage: 139000,
		status: "available",
		images: [
			"/assets/MITSUBISHI_1.jpg",
			"/assets/MITSUBISHI_2.jpg",
			"/assets/MITSUBISHI_3.jpg",
			"/assets/MITSUBISHI_4.jpg",
			"/assets/MITSUBISHI_5.jpg",
		],
		specifications: {
			engine: "2.4L 4-Cylinder",
			transmission: "CVT Automatic",
			fuelType: "Gasoline",
			color: "Ash Gray",
			doors: 4,
			seats: 5,
			drivetrain: "Front-Wheel Drive",
			vin: "1N4AL3AP8HC123456",
			features: [
				"TouchScreen Display",
				"Bluetooth Connectivity",
				"Backup Camera",
				"Push Button Start",
				"Automatic Climate Control",
			],
		},
		description:
			"Reliable and fuel-efficient 2017 Mitsubishi Outlander. Great value for money with comfort and control.",
	},
	{
		id: 8,
		title: "2015 Mitsubishi Outlander",
		make: "Mitsubishi",
		model: "Outlander",
		year: 2015,
		price: 7200,
		mileage: 150000,
		status: "available",
		images: [
			"/assets/m_1.jpg",
			"/assets/m_2.jpg",
			"/assets/m_3.jpg",
			"/assets/m_4.jpg",
			"/assets/m_5.jpg",
		],
		specifications: {
			engine: "2.4L 4-Cylinder",
			transmission: "6-Speed Automatic",
			fuelType: "Gasoline",
			color: "Summit White",
			doors: 4,
			seats: 5,
			drivetrain: "Front-Wheel Drive",
			vin: "1G1ZE5ST8GF123456",
			features: [
				"Anti-lock braking system",
				"Electronic stability control",
				"7 airbags, including driver's knee airbag",
				"Backup Camera",
				"Remote Start",
			],
		},
		description:
			"Spacious and comfortable 2015 Mitsubishi Outlander with modern technology features. Excellent fuel economy and smooth driving experience.",
	},
	{
		id: 9,
		title: "2016 Hyundai SantaFe",
		make: "Hyundai",
		model: "Santafe",
		year: 2016,
		price: 8100,
		mileage: 126000,
		status: "available",
		images: [
			"/assets/h_3.jpg",
			"/assets/h_1.jpg",
			"/assets/h_2.jpg",
			"/assets/h_4.jpg",
			"/assets/h_5.jpg",
			"/assets/h_6.jpg",
			"/assets/h_7.jpg",
		],
		specifications: {
			engine: "3L V6",
			transmission: "6-Speed Automatic with manual mode",
			fuelType: "Gasoline",
			color: "Sorrento Red",
			doors: 4,
			seats: 5,
			drivetrain: "Front-Wheel Drive",
			vin: "1G1ZE5ST8GF123456",
			features: [
				"Bluetooth Music streaming",
				"Parking Sensors",
				"7 airbags, including driver's knee airbag",
				"Backup Camera",
				"Remote Start",
			],
		},
		description:
			"Comfortable 2016 Hyundai SantaFe with modern technology features for work and road trips. Excellent fuel economy and smooth driving experience.",
	},
];
