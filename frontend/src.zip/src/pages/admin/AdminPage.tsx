// src/pages/AdminPage.tsx

import React, { useState, useEffect, FormEvent } from "react";
import {
	ShieldCheck,
	ListOrdered,
	Car,
	PlusCircle,
	Trash2,
	Edit,
} from "lucide-react";

// NOTE: This should point to your actual backend URL.
const API_BASE_URL = "https://goldlex-auto-server.onrender.com";

// --- Types/Interfaces ---
// Assumed structure for an order/inquiry fetched from the backend
interface Order {
	_id: string;
	carId: string;
	carTitle?: string; // Should be populated from the backend
	name: string;
	email?: string;
	phoneNumber: string;
	creditRequested: boolean;
	status: "Pending" | "Contacted" | "Closed";
	createdAt: string;
}

// Assumed structure for a car fetched from the backend
interface Car {
	_id: string;
	title: string;
	year: number;
	price: number;
	status: "available" | "sold";
	imageUrl?: string; // A primary image for the list view
	// Add other fields as needed for the edit form
}

// --- Mock API Functions (Replace with your actual API calls) ---
// This simulates fetching data and includes authentication headers.
const apiFetch = async (url: string, options: RequestInit = {}) => {
	const token = localStorage.getItem("admin_token"); // Example: Get token from storage
	const headers = {
		"Content-Type": "application/json",
		Authorization: `Bearer ${token}`, // Example: Bearer token auth
		...options.headers,
	};

	const response = await fetch(url, { ...options, headers });

	if (!response.ok) {
		const errorData = await response.json();
		throw new Error(errorData.message || "API request failed");
	}
	return response.json();
};

// --- Child Component: Manage Inquiries/Orders ---
const ManageInquiries: React.FC = () => {
	const [orders, setOrders] = useState<Order[]>([]);
	const [loading, setLoading] = useState(true);
	const [error, setError] = useState<string | null>(null);
	const [filter, setFilter] = useState<"all" | "credit">("all");

	useEffect(() => {
		const fetchOrders = async () => {
			try {
				setLoading(true);
				const data = await apiFetch(`${API_BASE_URL}/api/orders`);
				setOrders(data);
			} catch (err: any) {
				setError(err.message);
			} finally {
				setLoading(false);
			}
		};
		fetchOrders();
	}, []);

	const filteredOrders = orders.filter((order) =>
		filter === "credit" ? order.creditRequested : true,
	);

	if (loading) return <p>Loading inquiries...</p>;
	if (error) return <p className='text-red-500'>Error: {error}</p>;

	return (
		<div>
			<div className='flex justify-between items-center mb-4'>
				<h2 className='text-2xl font-bold text-secondary'>Car Inquiries</h2>
				<select
					value={filter}
					onChange={(e) => setFilter(e.target.value as "all" | "credit")}
					className='px-4 py-2 border rounded-md'>
					<option value='all'>All Inquiries</option>
					<option value='credit'>Credit Requested</option>
				</select>
			</div>
			<div className='overflow-x-auto bg-white rounded-lg shadow'>
				<table className='min-w-full divide-y divide-slate-200'>
					<thead className='bg-slate-50'>
						<tr>
							<th className='px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider'>
								Customer
							</th>
							<th className='px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider'>
								Car
							</th>
							<th className='px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider'>
								Credit Requested
							</th>
							<th className='px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider'>
								Status
							</th>
							<th className='px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider'>
								Date
							</th>
						</tr>
					</thead>
					<tbody className='bg-white divide-y divide-slate-200'>
						{filteredOrders.map((order) => (
							<tr key={order._id}>
								<td className='px-6 py-4 whitespace-nowrap'>
									<div className='font-medium text-secondary'>{order.name}</div>
									<div className='text-sm text-slate-500'>
										{order.phoneNumber}
									</div>
								</td>
								<td className='px-6 py-4 whitespace-nowrap text-sm text-slate-600'>
									{order.carTitle || `ID: ${order.carId}`}
								</td>
								<td className='px-6 py-4 whitespace-nowrap'>
									<span
										className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
											order.creditRequested
												? "bg-cyan-100 text-cyan-800"
												: "bg-slate-100 text-slate-800"
										}`}>
										{order.creditRequested ? "Yes" : "No"}
									</span>
								</td>
								<td className='px-6 py-4 whitespace-nowrap text-sm text-slate-600'>
									{order.status}
								</td>
								<td className='px-6 py-4 whitespace-nowrap text-sm text-slate-600'>
									{new Date(order.createdAt).toLocaleDateString()}
								</td>
							</tr>
						))}
					</tbody>
				</table>
			</div>
		</div>
	);
};

// --- Child Component: Manage Cars ---
const ManageCars: React.FC = () => {
	const [cars, setCars] = useState<Car[]>([]);
	const [loading, setLoading] = useState(true);
	const [error, setError] = useState<string | null>(null);
	const [showForm, setShowForm] = useState(false);
	// Add states for form fields...

	useEffect(() => {
		// Fetch cars from GET /api/cars
	}, []);

	const handleDelete = async (carId: string) => {
		if (window.confirm("Are you sure you want to delete this car?")) {
			try {
				await apiFetch(`${API_BASE_URL}/api/cars/${carId}`, {
					method: "DELETE",
				});
				setCars(cars.filter((c) => c._id !== carId));
			} catch (err: any) {
				alert(`Failed to delete car: ${err.message}`);
			}
		}
	};

	// In a real app, the form would be a separate, more complex component.
	const CarForm = () => (
		<div className='mt-6 bg-white p-6 rounded-lg shadow'>
			<h3 className='text-xl font-bold mb-4'>Upload New Car</h3>
			<form>
				{/* Add form fields for Make, Model, Year, Price, Specs, etc. */}
				<p className='text-slate-500'>
					Car upload form with all fields (Make, Model, Year, Price, Images,
					Specs, etc.) would go here.
				</p>
				<button
					type='submit'
					className='mt-4 px-4 py-2 bg-primary text-black rounded-md hover:bg-primary-dark'>
					Save Car
				</button>
			</form>
		</div>
	);

	return (
		<div>
			<div className='flex justify-between items-center mb-4'>
				<h2 className='text-2xl font-bold text-black'>Car Inventory</h2>
				<button
					onClick={() => setShowForm(!showForm)}
					className='flex items-center gap-2 px-4 py-2 bg-primary text-black rounded-md hover:bg-primary-dark'>
					<PlusCircle size={18} />
					{showForm ? "Cancel" : "Upload New Car"}
				</button>
			</div>

			{showForm && <CarForm />}

			<div className='mt-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6'>
				{/* Map over `cars` to display them */}
				{cars.map((car) => (
					<div
						key={car._id}
						className='bg-white rounded-lg shadow p-4 flex flex-col'>
						{/* Car details */}
						<div className='flex-grow'>
							<h4 className='font-bold text-secondary'>{car.title}</h4>
							<p className='text-sm text-slate-500'>
								{car.year} - ${car.price.toLocaleString()}
							</p>
						</div>
						<div className='mt-4 flex gap-2'>
							<button className='flex-1 text-sm flex items-center justify-center gap-2 px-3 py-1.5 border rounded-md hover:bg-slate-50'>
								<Edit size={14} /> Edit
							</button>
							<button
								onClick={() => handleDelete(car._id)}
								className='flex-1 text-sm flex items-center justify-center gap-2 px-3 py-1.5 border text-red-600 border-red-200 rounded-md hover:bg-red-50'>
								<Trash2 size={14} /> Delete
							</button>
						</div>
					</div>
				))}
			</div>
		</div>
	);
};

// --- Main Admin Page Component ---
const AdminPage: React.FC = () => {
	const [activeTab, setActiveTab] = useState<"inquiries" | "cars">("inquiries");
	const [isAuthenticated, setIsAuthenticated] = useState(true); // Placeholder for auth logic

	// Placeholder for real authentication check
	useEffect(() => {
		const token = localStorage.getItem("admin_token");
		if (!token) {
			setIsAuthenticated(false);
			// In a real app, you would redirect to a login page:
			// window.location.href = '/login';
		}
	}, []);

	if (!isAuthenticated) {
		return (
			<div className='text-center py-20'>
				<h1 className='text-2xl font-bold'>Access Denied</h1>
				<p>You must be logged in as an administrator to view this page.</p>
			</div>
		);
	}

	return (
		<div className='container mx-auto px-4 md:px-8 py-12 pt-24'>
			<div className='flex items-center gap-4 mb-8'>
				<ShieldCheck className='text-primary' size={40} />
				<div>
					<h1 className='text-3xl md:text-4xl font-bold text-secondary'>
						Admin Dashboard
					</h1>
					<p className='text-slate-500'>Manage inquiries and car inventory.</p>
				</div>
			</div>

			{/* Tab Navigation */}
			<div className='border-b border-slate-200 mb-8'>
				<nav className='-mb-px flex gap-6' aria-label='Tabs'>
					<button
						onClick={() => setActiveTab("inquiries")}
						className={`shrink-0 border-b-2 px-1 pb-4 text-sm font-medium ${
							activeTab === "inquiries"
								? "border-primary text-primary"
								: "border-transparent text-slate-500 hover:border-slate-300 hover:text-slate-700"
						}`}>
						Manage Inquiries
					</button>
					<button
						onClick={() => setActiveTab("cars")}
						className={`shrink-0 border-b-2 px-1 pb-4 text-sm font-medium ${
							activeTab === "cars"
								? "border-primary text-primary"
								: "border-transparent text-slate-500 hover:border-slate-300 hover:text-slate-700"
						}`}>
						Manage Cars
					</button>
				</nav>
			</div>

			{/* Active Tab Content */}
			<div>
				{activeTab === "inquiries" && <ManageInquiries />}
				{activeTab === "cars" && <ManageCars />}
			</div>
		</div>
	);
};

export default AdminPage;
