import React from 'react';
import HeroSection from '../components/home/HeroSection';
import AboutSection from '../components/home/AboutSection';
import ServicesSection from '../components/home/ServicesSection';
import TimelineSection from '../components/home/TimelineSection';
import TeamSection from '../components/home/TeamSection';
import PartsSection from '../components/home/PartsSection';
import TestimonialsSection from '../components/home/TestimonialsSection';
import ContactSection from '../components/home/ContactSection';

const HomePage: React.FC = () => {
  return (
    <div>
      <HeroSection />
      <AboutSection />
      <ServicesSection />
      <TimelineSection />
      <TeamSection />
      <PartsSection />
      <TestimonialsSection />
      <ContactSection />
    </div>
  );
};

export default HomePage;