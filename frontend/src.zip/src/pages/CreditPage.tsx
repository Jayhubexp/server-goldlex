import React, { useState } from "react";
// In your actual project, ensure these are correctly imported from their files.
import CreditSection from "../components/home/CreditSection";
const ScrollReveal: React.FC<{ children: React.ReactNode; delay?: number }> = ({
	children,
	delay,
}) => {
	return (
		<div className='scroll-reveal' style={{ transitionDelay: `${delay}ms` }}>
			{children}
		</div>
	);
};

import {
	CreditCard,
	Shield,
	Calculator,
	Clock,
	CheckCircle,
	FileText,
} from "lucide-react";

// Define your backend API URL. Make sure this matches your backend PORT.
const API_BASE_URL = "https://goldlex-auto-server.onrender.com";

const CreditFacilityPage: React.FC = () => {
	// State variables for form inputs (RENAMED to match backend express-validator schema)
	const [businessName, setBusinessName] = useState<string>("");
	const [yearsInBusiness, setYearsInBusiness] = useState<number | "">("");
	const [fullName, setFullName] = useState<string>(""); // RENAMED: was contactPerson
	const [phoneNumber, setPhoneNumber] = useState<string>("");
	const [emailAddress, setEmailAddress] = useState<string>("");
	const [desiredCreditAmount, setDesiredCreditAmount] = useState<string>(""); // RENAMED: was desiredCreditLimit, will be converted to number for payload
	const [additionalInfo, setAdditionalInfo] = useState<string>(""); // RENAMED: was additionalInformation

	// State variables for form submission status
	const [isLoading, setIsLoading] = useState<boolean>(false);
	const [message, setMessage] = useState<{
		type: "success" | "error";
		text: string;
	} | null>(null);

	// Function to handle form submission
	const handleSubmit = async (e: React.FormEvent) => {
		e.preventDefault(); // Prevent default form submission behavior (page reload)

		// Clear previous messages
		setMessage(null);

		// --- Frontend Validation (Updated to match backend schema names) ---
		if (!businessName.trim()) {
			setMessage({ type: "error", text: "Business Name is required." });
			return;
		}
		if (!fullName.trim()) {
			// RENAMED
			setMessage({ type: "error", text: "Full Name is required." });
			return;
		}
		if (!phoneNumber.trim()) {
			setMessage({ type: "error", text: "Phone Number is required." });
			return;
		}
		// Updated regex for phoneNumber to allow starting with 0
		if (!/^[\+]?\d{1,15}$/.test(phoneNumber)) {
			// This regex allows starting with 0
			setMessage({
				type: "error",
				text: "Please enter a valid phone number (e.g., 0xxxxxxxxx or +xxxxxxxxxx).",
			});
			return;
		}
		if (!emailAddress.trim()) {
			setMessage({ type: "error", text: "Email Address is required." });
			return;
		}
		// Basic email format validation
		if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailAddress)) {
			setMessage({
				type: "error",
				text: "Please enter a valid email address.",
			});
			return;
		}
		if (!desiredCreditAmount) {
			// RENAMED
			setMessage({
				type: "error",
				text: "Please select a desired credit amount.",
			});
			return;
		}
		// yearsInBusiness is optional and backend uses isFloat, so 0 is fine, empty string converted to null/undefined.

		setIsLoading(true); // Start loading state

		const formData = {
			businessName,
			yearsInBusiness:
				yearsInBusiness === "" ? undefined : Number(yearsInBusiness), // Convert to Number or undefined for optional float
			fullName, // RENAMED
			phoneNumber,
			emailAddress,
			desiredCreditAmount: Number(desiredCreditAmount), // CONVERTED TO NUMBER
			additionalInfo: additionalInfo || undefined, // RENAMED, send undefined if empty for optional string
		};

		try {
			const response = await fetch(`${API_BASE_URL}/api/credit-application`, {
				method: "POST",
				headers: {
					"Content-Type": "application/json",
				},
				body: JSON.stringify(formData),
			});

			if (!response.ok) {
				const errorData = await response.json();
				// Display specific validation errors if provided by backend
				if (errorData.errors && errorData.errors.length > 0) {
					const errorMessages = errorData.errors
						.map((err: any) => err.msg || err.message)
						.join("; ");
					throw new Error(errorMessages);
				}
				throw new Error(errorData.message || "Failed to submit application.");
			}

			const result = await response.json();
			setMessage({
				type: "success",
				text:
					result.message ||
					"Application submitted successfully! We will contact you soon.",
			});

			// Clear form fields on success
			setBusinessName("");
			setYearsInBusiness("");
			setFullName(""); // RENAMED
			setPhoneNumber("");
			setEmailAddress("");
			setDesiredCreditAmount(""); // RENAMED
			setAdditionalInfo(""); // RENAMED
		} catch (error: any) {
			console.error("Error submitting form:", error);
			setMessage({
				type: "error",
				text:
					error.message ||
					"An error occurred while submitting your application.",
			});
		} finally {
			setIsLoading(false); // End loading state
		}
	};
	return (
		<div className='pt-5'>
			<CreditSection />
			<section className='bg-gradient-to-r from-primary to-primary-dark text-black py-10'>
				<div className='container mx-auto px-4 md:px-8'>
					<ScrollReveal>
						<div className='max-w-3xl mx-auto text-center'>
							<h1 className='text-4xl md:text-5xl font-bold mb-6'>
								Flexible Credit Solutions
							</h1>
							<p className='text-xl opacity-90 mb-8'>
								Stock up your inventory with our hassle-free credit facility.
								Get the parts you need now, pay later with flexible terms
								tailored to your business.
							</p>
							<a
								href='#apply'
								className='inline-block px-8 py-3 bg-white text-primary font-semibold rounded-md hover:bg-opacity-90 transition-all duration-300'>
								Apply Now
							</a>
						</div>
					</ScrollReveal>
				</div>
			</section>

			{/* Benefits Section */}
			<section className='py-20 bg-white'>
				<div className='container mx-auto px-4 md:px-8'>
					<ScrollReveal>
						<div className='text-center mb-16'>
							<h2 className='text-3xl md:text-4xl font-bold text-secondary mb-4'>
								How Our Credit Facility Works
							</h2>
							<p className='text-slate-600 max-w-2xl mx-auto'>
								We understand that not every dealer has the cash flow to stockup
								or import the parts they need. Our Dealer Credit Program makes
								it easier for spare parts dealers to access funds, purchase in
								bulk, and grow their business without upfront financial
								pressure.
							</p>
						</div>
					</ScrollReveal>

					<div className='grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8'>
						{[
							{
								icon: <CreditCard className='text-primary' size={40} />,
								title: "Apply Online",
								description:
									"Submit a short form with your business information",
							},
							{
								icon: <Clock className='text-primary' size={40} />,
								title: "Get Matched With a Lender",
								description:
									"We connect you to vetted banks or individual lenders interested in supporting the auto parts trade.",
							},
							{
								icon: <Calculator className='text-primary' size={40} />,
								title: "Receive Your Loan",
								description:
									"Once approved, funds are immediately disbursed to your account and you are ready to stockup spare part products",
							},
							{
								icon: <Shield className='text-primary' size={40} />,
								title: "Repayment",
								description:
									"Flexible repayment terms are designed to fit your business cycle.",
							},
							{
								icon: <CheckCircle className='text-primary' size={40} />,
								title: "Quick Approval",
								description: "Fast application review and approval process",
							},
							{
								icon: <FileText className='text-primary' size={40} />,
								title: "Simple Documentation",
								description: "Minimal paperwork required for application",
							},
						].map((benefit, index) => (
							<ScrollReveal key={index} delay={index * 100}>
								<div className='bg-white p-6 rounded-lg shadow-lg hover:shadow-xl transition-all duration-300'>
									<div className='mb-4'>{benefit.icon}</div>
									<h3 className='text-xl font-bold text-secondary mb-2'>
										{benefit.title}
									</h3>
									<p className='text-slate-600'>{benefit.description}</p>
								</div>
							</ScrollReveal>
						))}
					</div>
				</div>
			</section>

			{/* Application Process */}
			<section id='apply' className='py-20 bg-slate-50'>
				<div className='container mx-auto px-4 md:px-8'>
					<ScrollReveal>
						<div className='text-center mb-16'>
							<h2 className='text-3xl md:text-4xl font-bold text-secondary mb-4'>
								Application Process
							</h2>
							<p className='text-slate-600 max-w-2xl mx-auto'>
								Get started with our simple application process and start
								building your inventory today.
							</p>
						</div>
					</ScrollReveal>

					<div className='max-w-3xl mx-auto'>
						<form
							className='bg-white p-8 rounded-lg shadow-lg'
							onSubmit={handleSubmit}>
							{" "}
							{/* Attach onSubmit handler */}
							<div className='grid grid-cols-1 md:grid-cols-2 gap-6 mb-6'>
								<div>
									<label
										className='block text-sm font-medium text-secondary mb-2'
										htmlFor='businessName'>
										Business Name
									</label>
									<input
										type='text'
										id='businessName' // Add id for label
										className='w-full px-4 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary'
										placeholder='Your business name'
										value={businessName} // Controlled component
										onChange={(e) => setBusinessName(e.target.value)} // Update state on change
										required // HTML5 validation
									/>
								</div>
								<div>
									<label
										className='block text-sm font-medium text-secondary mb-2'
										htmlFor='yearsInBusiness'>
										Years in Business
									</label>
									<input
										type='number'
										id='yearsInBusiness' // Add id for label
										className='w-full px-4 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary'
										placeholder='Number of years'
										value={yearsInBusiness} // Controlled component
										onChange={(e) =>
											setYearsInBusiness(
												e.target.value === "" ? "" : parseInt(e.target.value),
											)
										} // Handle empty string and parse
										min='0' // HTML5 validation
									/>
								</div>
							</div>
							<div className='grid grid-cols-1 md:grid-cols-2 gap-6 mb-6'>
								<div>
									<label
										className='block text-sm font-medium text-secondary mb-2'
										htmlFor='fullName'>
										{" "}
										{/* RENAMED label htmlFor */}
										Full Name {/* RENAMED label text */}
									</label>
									<input
										type='text'
										id='fullName' // RENAMED id
										className='w-full px-4 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary'
										placeholder='Full name'
										value={fullName} // RENAMED state value
										onChange={(e) => setFullName(e.target.value)} // RENAMED state setter
										required
									/>
								</div>
								<div>
									<label
										className='block text-sm font-medium text-secondary mb-2'
										htmlFor='phoneNumber'>
										Phone Number
									</label>
									<input
										type='tel'
										id='phoneNumber' // Add id for label
										className='w-full px-4 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary'
										placeholder='Your phone number'
										value={phoneNumber} // Controlled component
										onChange={(e) => setPhoneNumber(e.target.value)} // Update state on change
										required // HTML5 validation
									/>
								</div>
							</div>
							<div className='mb-6'>
								<label
									className='block text-sm font-medium text-secondary mb-2'
									htmlFor='emailAddress'>
									Email Address
								</label>
								<input
									type='email'
									id='emailAddress' // Add id for label
									className='w-full px-4 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary'
									placeholder='your@email.com'
									value={emailAddress} // Controlled component
									onChange={(e) => setEmailAddress(e.target.value)} // Update state on change
									required // HTML5 validation
								/>
							</div>
							<div className='mb-6'>
								<label
									className='block text-sm font-medium text-secondary mb-2'
									htmlFor='desiredCreditAmount'>
									{" "}
									{/* RENAMED label htmlFor */}
									Desired Credit Amount {/* RENAMED label text */}
								</label>
								<select
									id='desiredCreditAmount' // RENAMED id
									className='w-full px-4 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary'
									value={desiredCreditAmount} // RENAMED state value
									onChange={(e) => setDesiredCreditAmount(e.target.value)} // RENAMED state setter
									required>
									<option value=''>Select credit limit range</option>
									<option value='5000'>$5,000 - $10,000</option>
									<option value='10000'>$10,000 - $25,000</option>
									<option value='25000'>$25,000 - $50,000</option>
									<option value='50000'>$50,000+</option>
								</select>
							</div>
							<div className='mb-6'>
								<label
									className='block text-sm font-medium text-secondary mb-2'
									htmlFor='additionalInfo'>
									{" "}
									{/* RENAMED label htmlFor */}
									Additional Information {/* RENAMED label text */}
								</label>
								<textarea
									id='additionalInfo' // RENAMED id
									className='w-full px-4 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary'
									rows={4}
									placeholder='Tell us more about your business and credit needs'
									value={additionalInfo} // RENAMED state value
									onChange={(e) => setAdditionalInfo(e.target.value)} // RENAMED state setter
								></textarea>
							</div>
							{/* Message display area */}
							{message && (
								<div
									className={`mt-4 p-3 rounded-md text-sm ${
										message.type === "success"
											? "bg-green-100 text-green-700"
											: "bg-red-100 text-red-700"
									}`}>
									{message.text}
								</div>
							)}
							<button
								type='submit' // Ensure type is submit
								className='w-full bg-primary text-black font-semibold py-3 rounded-md hover:bg-primary-dark transition-colors duration-300'
								disabled={isLoading} // Disable button when loading
							>
								{isLoading ? "Submitting..." : "Submit Application"}
							</button>
						</form>
					</div>
				</div>
			</section>
		</div>
	);
};

export default CreditFacilityPage;
