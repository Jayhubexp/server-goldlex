import React, { useState, useMemo } from "react";
import { ScrollReveal } from "../components/animations/ScrollReveal";
import { Search, Filter, Eye, DollarSign, Gauge } from "lucide-react";
import { Link } from "react-router-dom";
import { carsData, Car } from "../data/carsData";

const CarsPage: React.FC = () => {
	const [activeTab, setActiveTab] = useState<"available" | "sold">("available");
	const [searchTerm, setSearchTerm] = useState("");
	const [filters, setFilters] = useState({
		make: "",
		model: "",
		yearMin: "",
		yearMax: "",
		priceMin: "",
		priceMax: "",
	});

	const filteredCars = useMemo(() => {
		return carsData.filter((car) => {
			const matchesTab = car.status === activeTab;
			const matchesSearch =
				car.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
				car.make.toLowerCase().includes(searchTerm.toLowerCase()) ||
				car.model.toLowerCase().includes(searchTerm.toLowerCase());

			const matchesMake =
				!filters.make ||
				car.make.toLowerCase().includes(filters.make.toLowerCase());
			const matchesModel =
				!filters.model ||
				car.model.toLowerCase().includes(filters.model.toLowerCase());
			const matchesYearMin =
				!filters.yearMin || car.year >= parseInt(filters.yearMin);
			const matchesYearMax =
				!filters.yearMax || car.year <= parseInt(filters.yearMax);
			const matchesPriceMin =
				!filters.priceMin || car.price >= parseInt(filters.priceMin);
			const matchesPriceMax =
				!filters.priceMax || car.price <= parseInt(filters.priceMax);

			return (
				matchesTab &&
				matchesSearch &&
				matchesMake &&
				matchesModel &&
				matchesYearMin &&
				matchesYearMax &&
				matchesPriceMin &&
				matchesPriceMax
			);
		});
	}, [activeTab, searchTerm, filters]);

	const availableCount = carsData.filter(
		(car) => car.status === "available",
	).length;
	const soldCount = carsData.filter((car) => car.status === "sold").length;

	const resetFilters = () => {
		setFilters({
			make: "",
			model: "",
			yearMin: "",
			yearMax: "",
			priceMin: "",
			priceMax: "",
		});
		setSearchTerm("");
	};

	return (
		<div className='pt-20'>
			{/* Hero Section */}
			<section
				className='relative h-96 flex items-center justify-center bg-cover bg-center'
				style={{
					backgroundImage:
						'linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.7)), url("https://images.pexels.com/photos/244206/pexels-photo-244206.jpeg?auto=compress&cs=tinysrgb&w=1920")',
				}}>
				<div className='container mx-auto px-4 text-center'>
					<ScrollReveal>
						<h1 className='text-4xl md:text-5xl font-bold text-white mb-4'>
							Imported Cars from Abroad
						</h1>
						<p className='text-xl text-white opacity-90 max-w-2xl mx-auto'>
							Explore and buy quality vehicles delivered to your door
						</p>
					</ScrollReveal>
				</div>
			</section>

			{/* Search and Filter Section */}
			<section className='py-8 bg-white border-b'>
				<div className='container mx-auto px-4 md:px-8'>
					<div className='flex flex-col lg:flex-row gap-6'>
						{/* Search Bar */}
						<div className='flex-grow'>
							<div className='relative'>
								<Search
									className='absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400'
									size={20}
								/>
								<input
									type='text'
									placeholder='Search by make, model, or title...'
									className='w-full pl-10 pr-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary'
									value={searchTerm}
									onChange={(e) => setSearchTerm(e.target.value)}
								/>
							</div>
						</div>

						{/* Filter Toggle */}
						<button
							className='lg:hidden flex items-center gap-2 px-4 py-3 bg-slate-100 rounded-lg hover:bg-slate-200 transition-colors duration-300'
							onClick={() => {
								/* Toggle filter visibility on mobile */
							}}>
							<Filter size={20} />
							Filters
						</button>
					</div>

					{/* Filters */}
					<div className='grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mt-6'>
						<input
							type='text'
							placeholder='Make'
							className='px-3 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary'
							value={filters.make}
							onChange={(e) => setFilters({ ...filters, make: e.target.value })}
						/>
						<input
							type='text'
							placeholder='Model'
							className='px-3 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary'
							value={filters.model}
							onChange={(e) =>
								setFilters({ ...filters, model: e.target.value })
							}
						/>
						<input
							type='number'
							placeholder='Min Year'
							className='px-3 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary'
							value={filters.yearMin}
							onChange={(e) =>
								setFilters({ ...filters, yearMin: e.target.value })
							}
						/>
						<input
							type='number'
							placeholder='Max Year'
							className='px-3 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary'
							value={filters.yearMax}
							onChange={(e) =>
								setFilters({ ...filters, yearMax: e.target.value })
							}
						/>
						<input
							type='number'
							placeholder='Min Price'
							className='px-3 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary'
							value={filters.priceMin}
							onChange={(e) =>
								setFilters({ ...filters, priceMin: e.target.value })
							}
						/>
						<input
							type='number'
							placeholder='Max Price'
							className='px-3 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary'
							value={filters.priceMax}
							onChange={(e) =>
								setFilters({ ...filters, priceMax: e.target.value })
							}
						/>
					</div>

					<button
						onClick={resetFilters}
						className='mt-4 px-4 py-2 text-primary hover:text-primary-dark transition-colors duration-300'>
						Clear All Filters
					</button>
				</div>
			</section>

			{/* Tabs Section */}
			<section className='py-8 bg-slate-50'>
				<div className='container mx-auto px-4 md:px-8'>
					<div className='flex justify-center mb-8'>
						<div className='bg-white rounded-lg p-1 shadow-md'>
							<button
								className={`px-6 py-3 rounded-md font-medium transition-all duration-300 ${
									activeTab === "available"
										? "bg-primary text-white shadow-md"
										: "text-slate-600 hover:text-primary"
								}`}
								onClick={() => setActiveTab("available")}>
								Available Cars ({availableCount})
							</button>
							<button
								className={`px-6 py-3 rounded-md font-medium transition-all duration-300 ${
									activeTab === "sold"
										? "bg-primary text-white shadow-md"
										: "text-slate-600 hover:text-primary"
								}`}
								onClick={() => setActiveTab("sold")}>
								Sold Cars ({soldCount})
							</button>
						</div>
					</div>

					{/* Cars Grid */}
					<div className='grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8'>
						{filteredCars.map((car, index) => (
							<ScrollReveal key={car.id} delay={index * 100}>
								<div className='bg-white rounded-lg overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300 group'>
									<div className='relative overflow-hidden h-48'>
										<img
											src={car.images[0]}
											alt={car.title}
											className='w-full h-full object-cover transition-transform duration-500 group-hover:scale-110'
										/>
										<div
											className={`absolute top-3 right-3 px-3 py-1 rounded-full text-sm font-medium ${
												car.status === "available"
													? "bg-green-500 text-white"
													: "bg-red-500 text-white"
											}`}>
											{car.status === "available" ? "Available" : "Sold"}
										</div>
									</div>

									<div className='p-6'>
										<h3 className='text-xl font-bold text-secondary mb-2'>
											{car.title}
										</h3>
										<div className='space-y-2 mb-4'>
											<div className='flex items-center text-slate-600'>
												<Gauge size={16} className='mr-2' />
												<span>{car.mileage.toLocaleString()} miles</span>
											</div>
											<div className='flex items-center text-slate-600'>
												<DollarSign size={16} className='mr-2' />
												<span className='font-semibold text-primary'>
													${car.price.toLocaleString()}
												</span>
											</div>
										</div>

										<Link
											to={`/cars/${car.id}`}
											className='flex items-center justify-center gap-2 w-full bg-primary text-black py-2 rounded-md hover:bg-primary-dark transition-colors duration-300'>
											<Eye size={18} />
											View Details
										</Link>
									</div>
								</div>
							</ScrollReveal>
						))}
					</div>

					{filteredCars.length === 0 && (
						<div className='text-center py-12'>
							<p className='text-slate-600 text-lg'>
								No cars found matching your criteria.
							</p>
							<button
								onClick={resetFilters}
								className='mt-4 px-6 py-2 bg-primary text-white rounded-md hover:bg-primary-dark transition-colors duration-300'>
								Clear Filters
							</button>
						</div>
					)}
				</div>
			</section>
		</div>
	);
};

export default CarsPage;
