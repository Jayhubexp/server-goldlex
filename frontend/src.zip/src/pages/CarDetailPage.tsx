import React, { useState } from "react";
import { useParams, Link } from "react-router-dom";
import { ScrollReveal } from "../components/animations/ScrollReveal";
import {
	ArrowLeft,
	Phone,
	Mail,
	Calendar,
	Gauge,
	DollarSign,
	Car as CarIcon,
	Fuel,
	Settings,
	Users,
	ChevronLeft,
	ChevronRight,
	CheckCircle,
} from "lucide-react";
import { carsData } from "../data/carsData";

const API_BASE_URL = "https://goldlex-auto-server.onrender.com";

const CarDetailPage: React.FC = () => {
	const { id } = useParams<{ id: string }>();
	const [currentImageIndex, setCurrentImageIndex] = useState(0);
	const [showContactForm, setShowContactForm] = useState(false);

	// State for the contact form fields
	const [formName, setFormName] = useState<string>("");
	const [formPhoneNumber, setFormPhoneNumber] = useState<string>("");
	const [formEmail, setFormEmail] = useState<string>("");
	const [formMessage, setFormMessage] = useState<string>("");

	// State for form submission status
	const [isLoading, setIsLoading] = useState(false);
	const [submitMessage, setSubmitMessage] = useState<{
		type: "success" | "error";
		text: string;
	} | null>(null);

	const car = carsData.find((c) => c.id === parseInt(id || "0"));

	if (!car) {
		return (
			<div className='pt-20 min-h-screen flex items-center justify-center'>
				<div className='text-center'>
					<h1 className='text-2xl font-bold text-secondary mb-4'>
						Car Not Found
					</h1>
					<Link to='/cars' className='text-primary hover:text-primary-dark'>
						← Back to Cars
					</Link>
				</div>
			</div>
		);
	}

	const nextImage = () => {
		setCurrentImageIndex((prev) => (prev + 1) % car.images.length);
	};

	const prevImage = () => {
		setCurrentImageIndex(
			(prev) => (prev - 1 + car.images.length) % car.images.length,
		);
	};

	const handleCarFormSubmit = async (e: React.FormEvent) => {
		e.preventDefault(); // Prevent default browser form submission

		setSubmitMessage(null); // Clear previous messages

		// Frontend validation (matching backend's express-validator rules)
		if (!formName.trim()) {
			setSubmitMessage({ type: "error", text: "Name is required." });
			return;
		}
		if (!formPhoneNumber.trim()) {
			setSubmitMessage({ type: "error", text: "Phone number is required." });
			return;
		}
		// Phone number regex validation (matching the backend regex)
		if (!/^(0\d{9}|\+\d{15}|\d{10})$/.test(formPhoneNumber)) {
			setSubmitMessage({
				type: "error",
				text: "Please enter a valid phone number (10 digits, or 15 digits starting with +).",
			});
			return;
		}
		if (formEmail.trim() && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formEmail)) {
			setSubmitMessage({
				type: "error",
				text: "Please enter a valid email address.",
			});
			return;
		}
		if (!formMessage.trim()) {
			setSubmitMessage({ type: "error", text: "Message is required." });
			return;
		}

		setIsLoading(true); // Set loading state

		const formData = {
			name: formName,
			phoneNumber: formPhoneNumber,
			email: formEmail.trim() === "" ? undefined : formEmail, // Send undefined if email is empty
			message: formMessage,
		};

		try {
			const response = await fetch(`${API_BASE_URL}/api/car-form`, {
				method: "POST",
				headers: {
					"Content-Type": "application/json",
				},
				body: JSON.stringify(formData),
			});

			if (!response.ok) {
				const errorData = await response.json();
				// Display specific validation errors from express-validator
				if (errorData.errors && errorData.errors.length > 0) {
					const errorMessages = errorData.errors
						.map((err: any) => err.msg || err.message)
						.join("; ");
					throw new Error(errorMessages);
				}
				throw new Error(errorData.message || "Failed to submit car form.");
			}

			const result = await response.json();
			setSubmitMessage({
				type: "success",
				text: result.message || "Your message has been sent successfully!",
			});

			// Clear form fields after successful submission
			setFormName("");
			setFormPhoneNumber("");
			setFormEmail("");
			setFormMessage(
				`I'm interested in the ${car.title}. Please contact me with more information.`,
			); // Reset to default message

			// Optionally hide the form after success
			// setShowContactForm(false);
		} catch (error: any) {
			console.error("Error submitting car form:", error);
			setSubmitMessage({
				type: "error",
				text: error.message || "An unexpected error occurred.",
			});
		} finally {
			setIsLoading(false); // End loading state
		}
	};

	return (
		<div className='pt-20'>
			{/* Navigation */}
			<section className='py-4 bg-slate-50 border-b'>
				<div className='container mx-auto px-4 md:px-8'>
					<Link
						to='/cars'
						className='flex items-center gap-2 text-primary hover:text-primary-dark transition-colors duration-300'>
						<ArrowLeft size={20} />
						Back to Cars
					</Link>
				</div>
			</section>

			<div className='container mx-auto px-4 md:px-8 py-8'>
				<div className='grid grid-cols-1 lg:grid-cols-2 gap-12'>
					{/* Image Gallery */}
					<ScrollReveal direction='left'>
						<div className='space-y-4'>
							<div className='relative overflow-hidden rounded-lg shadow-lg'>
								<img
									src={car.images[currentImageIndex]}
									alt={`${car.title} - Image ${currentImageIndex + 1}`}
									className='w-full h-96 object-cover'
								/>

								{car.images.length > 1 && (
									<>
										<button
											onClick={prevImage}
											className='absolute left-4 top-1/2 transform -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white p-2 rounded-full transition-colors duration-300'>
											<ChevronLeft size={24} />
										</button>
										<button
											onClick={nextImage}
											className='absolute right-4 top-1/2 transform -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white p-2 rounded-full transition-colors duration-300'>
											<ChevronRight size={24} />
										</button>
									</>
								)}

								<div
									className={`absolute top-4 right-4 px-3 py-1 rounded-full text-sm font-medium ${
										car.status === "available"
											? "bg-green-500 text-white"
											: "bg-red-500 text-white"
									}`}>
									{car.status === "available" ? "Available" : "Sold"}
								</div>
							</div>

							{/* Thumbnail Gallery */}
							{car.images.length > 1 && (
								<div className='flex gap-2 overflow-x-auto'>
									{car.images.map((image, index) => (
										<button
											key={index}
											onClick={() => setCurrentImageIndex(index)}
											className={`flex-shrink-0 w-20 h-20 rounded-md overflow-hidden border-2 transition-all duration-300 ${
												currentImageIndex === index
													? "border-primary"
													: "border-transparent hover:border-slate-300"
											}`}>
											<img
												src={image}
												alt={`${car.title} thumbnail ${index + 1}`}
												className='w-full h-full object-cover'
											/>
										</button>
									))}
								</div>
							)}
						</div>
					</ScrollReveal>

					{/* Car Details */}
					<ScrollReveal direction='right'>
						<div className='space-y-6'>
							<div>
								<h1 className='text-3xl md:text-4xl font-bold text-secondary mb-2'>
									{car.title}
								</h1>
								<p className='text-slate-600 text-lg'>{car.description}</p>
							</div>

							{/* Key Stats */}
							<div className='grid grid-cols-2 md:grid-cols-4 gap-4'>
								<div className='bg-slate-50 p-4 rounded-lg text-center'>
									<Calendar className='text-primary mx-auto mb-2' size={24} />
									<p className='text-sm text-slate-600'>Year</p>
									<p className='font-bold text-secondary'>{car.year}</p>
								</div>
								<div className='bg-slate-50 p-4 rounded-lg text-center'>
									<Gauge className='text-primary mx-auto mb-2' size={24} />
									<p className='text-sm text-slate-600'>Mileage</p>
									<p className='font-bold text-secondary'>
										{car.mileage.toLocaleString()}
									</p>
								</div>
								<div className='bg-slate-50 p-4 rounded-lg text-center'>
									<DollarSign className='text-primary mx-auto mb-2' size={24} />
									<p className='text-sm text-slate-600'>Price</p>
									<p className='font-bold text-primary'>
										${car.price.toLocaleString()}
									</p>
								</div>
								<div className='bg-slate-50 p-4 rounded-lg text-center'>
									<CarIcon className='text-primary mx-auto mb-2' size={24} />
									<p className='text-sm text-slate-600'>Status</p>
									<p
										className={`font-bold ${
											car.status === "available"
												? "text-green-600"
												: "text-red-600"
										}`}>
										{car.status === "available" ? "Available" : "Sold"}
									</p>
								</div>
							</div>

							{/* Specifications */}
							<div className='bg-white border border-slate-200 rounded-lg p-6'>
								<h2 className='text-2xl font-bold text-secondary mb-4'>
									Specifications
								</h2>
								<div className='grid grid-cols-1 md:grid-cols-2 gap-4'>
									<div className='flex items-center gap-3'>
										<Settings className='text-primary' size={20} />
										<div>
											<p className='text-sm text-slate-600'>Engine</p>
											<p className='font-medium'>{car.specifications.engine}</p>
										</div>
									</div>
									<div className='flex items-center gap-3'>
										<Settings className='text-primary' size={20} />
										<div>
											<p className='text-sm text-slate-600'>Transmission</p>
											<p className='font-medium'>
												{car.specifications.transmission}
											</p>
										</div>
									</div>
									<div className='flex items-center gap-3'>
										<Fuel className='text-primary' size={20} />
										<div>
											<p className='text-sm text-slate-600'>Fuel Type</p>
											<p className='font-medium'>
												{car.specifications.fuelType}
											</p>
										</div>
									</div>
									<div className='flex items-center gap-3'>
										<CarIcon className='text-primary' size={20} />
										<div>
											<p className='text-sm text-slate-600'>Color</p>
											<p className='font-medium'>{car.specifications.color}</p>
										</div>
									</div>
									<div className='flex items-center gap-3'>
										<Users className='text-primary' size={20} />
										<div>
											<p className='text-sm text-slate-600'>Seats</p>
											<p className='font-medium'>{car.specifications.seats}</p>
										</div>
									</div>
									<div className='flex items-center gap-3'>
										<Settings className='text-primary' size={20} />
										<div>
											<p className='text-sm text-slate-600'>Drivetrain</p>
											<p className='font-medium'>
												{car.specifications.drivetrain}
											</p>
										</div>
									</div>
								</div>

								<div className='mt-4 pt-4 border-t border-slate-200'>
									<p className='text-sm text-slate-600 mb-1'>VIN</p>
									<p className='font-mono text-sm'>{car.specifications.vin}</p>
								</div>
							</div>

							{/* Features */}
							<div className='bg-white border border-slate-200 rounded-lg p-6'>
								<h2 className='text-2xl font-bold text-secondary mb-4'>
									Features
								</h2>
								<div className='grid grid-cols-1 md:grid-cols-2 gap-2'>
									{car.specifications.features.map((feature, index) => (
										<div key={index} className='flex items-center gap-2'>
											<CheckCircle className='text-primary' size={16} />
											<span className='text-slate-700'>{feature}</span>
										</div>
									))}
								</div>
							</div>

							{/* Contact Section */}
							{car.status === "available" && (
								<div className='bg-primary/5 border border-primary/20 rounded-lg p-6'>
									<h2 className='text-2xl font-bold text-secondary mb-4'>
										Interested in this car?
									</h2>
									<p className='text-slate-600 mb-4'>
										Contact us to schedule a viewing or get more information
										about this vehicle.
									</p>
									<div className='flex flex-col sm:flex-row gap-4'>
										<a
											href='tel:+233204805119'
											className='flex items-center justify-center gap-2 px-6 py-3 bg-primary text-primary rounded-md hover:bg-primary-dark transition-colors duration-300'>
											<Phone size={18} />
											Call Now
										</a>
										<button
											onClick={() => setShowContactForm(!showContactForm)}
											className='flex items-center justify-center gap-2 px-6 py-3 border border-primary text-primary rounded-md hover:bg-primary hover:text-emerald-800 transition-colors duration-300'>
											<Mail size={18} />
											Send Message
										</button>
									</div>

									{/* Contact Form */}
									{showContactForm && (
										<div className='mt-6 p-4 bg-white rounded-lg border'>
											<form
												className='space-y-4'
												onSubmit={handleCarFormSubmit}>
												<div className='grid grid-cols-1 md:grid-cols-2 gap-4'>
													<input
														type='text'
														placeholder='Your Name'
														className='px-4 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary'
														value={formName}
														onChange={(e) => setFormName(e.target.value)}
														required
													/>
													<input
														type='email'
														placeholder='Your email (optional)' // Indicate optional
														className='px-4 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary'
														value={formEmail}
														onChange={(e) => setFormEmail(e.target.value)}
													/>
												</div>
												<input
													type='tel'
													placeholder='Your Phone Number'
													className='w-full px-4 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary'
													value={formPhoneNumber}
													onChange={(e) => setFormPhoneNumber(e.target.value)}
													required
												/>
												<textarea
													placeholder={`I'm interested in the ${car.title}. Please contact me with more information.`}
													rows={4}
													className='w-full px-4 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary'
													value={formMessage}
													onChange={(e) => setFormMessage(e.target.value)}
													required // message is required by backend
												></textarea>

												{/* Submission message display */}
												{submitMessage && (
													<div
														className={`mt-4 p-3 rounded-md text-sm ${
															submitMessage.type === "success"
																? "bg-green-100 text-green-700"
																: "bg-red-100 text-red-700"
														}`}>
														{submitMessage.text}
													</div>
												)}

												<button
													type='submit'
													className='w-full bg-primary text-black py-2 rounded-md hover:bg-primary-dark transition-colors duration-300'
													disabled={isLoading}>
													{isLoading ? "Sending..." : "Send Message"}
												</button>
											</form>
										</div>
									)}
								</div>
							)}
						</div>
					</ScrollReveal>
				</div>
			</div>
		</div>
	);
};

export default CarDetailPage;
