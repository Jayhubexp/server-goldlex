import React, { useState } from "react";
// Placeholder components due to unresolved paths in the environment.
// In your actual project, ensure these are correctly imported from their files:
// import { ScrollReveal } from "../components/animations/ScrollReveal";
import OrderSection from "../components/home/OrderSection";

// Placeholder for ScrollReveal component
const ScrollReveal: React.FC<{ children: React.ReactNode }> = ({
	children,
}) => {
	// Replace this with the actual content of your ScrollReveal component from "../components/animations/ScrollReveal"
	return <div className='scroll-reveal'>{children}</div>;
};

import { ShoppingCart, Plus, Minus, Trash2 } from "lucide-react";

// Define your backend API URL.
// In development, this will point to your local Node.js server.
// In production, it should be your deployed backend URL.
// Consider using environment variables in your build process (e.g., process.env.REACT_APP_BACKEND_URL)
const API_BASE_URL = "https://goldlex-auto-server.onrender.com"; // IMPORTANT: Match your backend PORT here

interface Part {
	id: number;
	name: string;
	category: string;
	price: number;
	stock: number;
	image: string;
}

const availableParts: Part[] = [
	{
		id: 1,
		name: "Premium Brake Pads",
		category: "Brake System",
		price: 45.99,
		stock: 150,
		image:
			"https://images.pexels.com/photos/12051370/pexels-photo-12051370.jpeg",
	},
	{
		id: 2,
		name: "High-Performance Oil Filter",
		category: "Engine Components",
		price: 12.99,
		stock: 200,
		image: "https://images.pexels.com/photos/9800002/pexels-photo-9800002.jpeg",
	},
	{
		id: 3,
		name: "LED Headlight Assembly",
		category: "Lighting",
		price: 189.99,
		stock: 75,
		image: "https://images.pexels.com/photos/9553291/pexels-photo-9553291.jpeg",
	},
	{
		id: 4,
		name: "Transmission Gear Set",
		category: "Transmission",
		price: 245.0,
		stock: 45,
		image: "https://images.pexels.com/photos/4489749/pexels-photo-4489749.jpeg",
	},
];

interface OrderItem extends Part {
	quantity: number;
}

const OrderPage: React.FC = () => {
	const [orderItems, setOrderItems] = useState<OrderItem[]>([]);
	const [searchTerm, setSearchTerm] = useState("");
	const [selectedCategory, setSelectedCategory] = useState("All");
	// State variables for customer details
	const [name, setName] = useState<string>("");
	const [phoneNumber, setPhoneNumber] = useState<string>("");
	const [creditRequested, setCreditRequested] = useState<boolean>(false);
	// State variables for handling API call status and messages
	const [isLoading, setIsLoading] = useState(false);
	const [message, setMessage] = useState<{
		type: "success" | "error";
		text: string;
	} | null>(null);

	const categories = [
		"All",
		...new Set(availableParts.map((part) => part.category)),
	];

	const filteredParts = availableParts.filter((part) => {
		const matchesSearch = part.name
			.toLowerCase()
			.includes(searchTerm.toLowerCase());
		const matchesCategory =
			selectedCategory === "All" || part.category === selectedCategory;
		return matchesSearch && matchesCategory;
	});

	const addToOrder = (part: Part) => {
		setOrderItems((prev) => {
			const existing = prev.find((item) => item.id === part.id);
			if (existing) {
				return prev.map((item) =>
					item.id === part.id
						? { ...item, quantity: Math.min(item.quantity + 1, item.stock) }
						: item,
				);
			}
			return [...prev, { ...part, quantity: 1 }];
		});
	};

	const updateQuantity = (id: number, newQuantity: number) => {
		setOrderItems((prev) =>
			prev.map((item) =>
				item.id === id
					? {
							...item,
							quantity: Math.min(Math.max(1, newQuantity), item.stock),
					  }
					: item,
			),
		);
	};

	const removeItem = (id: number) => {
		setOrderItems((prev) => prev.filter((item) => item.id !== id));
	};

	const total = orderItems.reduce(
		(sum, item) => sum + item.price * item.quantity,
		0,
	);

	// Function to handle the order submission
	const handleSubmitOrder = async () => {
		// Clear any previous messages before attempting a new submission
		setMessage(null);

		// Frontend validation for order items
		if (orderItems.length === 0) {
			setMessage({
				type: "error",
				text: "Your order list is empty. Please add items before submitting.",
			});
			return;
		}

		// Frontend validation for customer details
		if (!name.trim() || !phoneNumber.trim()) {
			setMessage({
				type: "error",
				text: "Please enter your name and phone number.",
			});
			return;
		}
		if (!/^\+?[\d\s-]{10,}$/.test(phoneNumber)) {
			setMessage({ type: "error", text: "Please enter a valid phone number." });
			return;
		}

		setIsLoading(true); // Start loading state

		// Prepare the data to send to the backend
		const orderData = {
			products: orderItems.map((item) => ({
				productName: item.name,
				quantity: item.quantity,
				price: item.price,
			})),
			name: name,
			phoneNumber: phoneNumber,
			creditRequested: creditRequested,
		};

		try {
			const response = await fetch(`${API_BASE_URL}/api/order`, {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify(orderData),
			});

			if (!response.ok) {
				const errorData = await response.json();
				throw new Error(errorData.message || "Failed to submit order");
			}

			const result = await response.json();
			setMessage({
				type: "success",
				text: result.message || "Order submitted successfully!",
			});

			// Clear form
			setOrderItems([]);
			setName("");
			setPhoneNumber("");
			setCreditRequested(false);
		} catch (error: any) {
			setMessage({
				type: "error",
				text: error.message || "An unexpected error occurred.",
			});
		} finally {
			setIsLoading(false);
		}
	};

	return (
		<div className='pt-0'>
			<OrderSection /> {/* Uses the placeholder OrderSection */}
			<section className='bg-gradient-to-r from-primary to-primary-dark text-black py-20'>
				<div className='container mx-auto px-4 md:px-8'>
					<ScrollReveal>
						{" "}
						{/* Uses the placeholder ScrollReveal */}
						<div className='max-w-3xl mx-auto text-center'>
							<h1 className='text-4xl md:text-5xl font-bold mb-6'>
								Order Parts
							</h1>
							<p className='text-xl opacity-90'>
								Browse our inventory and create your order list with ease.
							</p>
						</div>
					</ScrollReveal>
				</div>
			</section>
			<section className='py-20'>
				<div className='container mx-auto px-4 md:px-8'>
					<div className='grid grid-cols-1 lg:grid-cols-3 gap-8'>
						{/* Parts Catalog */}
						<div className='lg:col-span-2'>
							<div className='mb-8'>
								<div className='flex flex-col sm:flex-row gap-4 mb-6'>
									<input
										type='text'
										placeholder='Search parts...'
										className='flex-grow px-4 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary'
										value={searchTerm}
										onChange={(e) => setSearchTerm(e.target.value)}
									/>
									<select
										className='px-4 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary'
										value={selectedCategory}
										onChange={(e) => setSelectedCategory(e.target.value)}>
										{categories.map((category) => (
											<option key={category} value={category}>
												{category}
											</option>
										))}
									</select>
								</div>

								<div className='grid grid-cols-1 md:grid-cols-2 gap-6'>
									{filteredParts.map((part) => (
										<div
											key={part.id}
											className='bg-white rounded-lg shadow-md overflow-hidden'>
											<img
												src={part.image}
												alt={part.name}
												className='w-full h-48 object-cover'
											/>
											<div className='p-4'>
												<h3 className='text-lg font-semibold text-secondary mb-2'>
													{part.name}
												</h3>
												<p className='text-slate-600 mb-2'>{part.category}</p>
												<div className='flex justify-between items-center'>
													<span className='text-primary font-bold'>
														${part.price.toFixed(2)}
													</span>
													<span className='text-slate-600'>
														Stock: {part.stock}
													</span>
												</div>
												<button
													onClick={() => addToOrder(part)}
													className='w-full mt-4 bg-primary text-black py-2 rounded-md hover:bg-primary-dark transition-colors duration-300 flex items-center justify-center gap-2'>
													<Plus size={18} />
													Add to Order
												</button>
											</div>
										</div>
									))}
								</div>
							</div>
						</div>

						{/* Order Summary */}
						<div className='lg:col-span-1'>
							<div className='bg-white rounded-lg shadow-lg p-6 sticky top-24'>
								<div className='flex items-center gap-2 mb-6'>
									<ShoppingCart className='text-primary' size={24} />
									<h2 className='text-2xl font-bold text-secondary'>
										Order Summary
									</h2>
								</div>

								{orderItems.length === 0 ? (
									<p className='text-slate-600 text-center py-8'>
										Your order list is empty
									</p>
								) : (
									<div className='space-y-4'>
										{orderItems.map((item) => (
											<div
												key={item.id}
												className='flex items-center gap-4 py-4 border-b'>
												<img
													src={item.image}
													alt={item.name}
													className='w-16 h-16 object-cover rounded'
												/>
												<div className='flex-grow'>
													<h3 className='font-medium text-secondary'>
														{item.name}
													</h3>
													<p className='text-sm text-slate-600'>
														${item.price.toFixed(2)} each
													</p>
												</div>
												<div className='flex items-center gap-2'>
													<button
														onClick={() =>
															updateQuantity(item.id, item.quantity - 1)
														}
														className='p-1 hover:bg-slate-100 rounded'>
														<Minus size={16} />
													</button>
													<input
														type='number'
														min='1'
														max={item.stock}
														value={item.quantity}
														onChange={(e) =>
															updateQuantity(
																item.id,
																parseInt(e.target.value) || 1,
															)
														}
														className='w-16 text-center border rounded-md'
													/>
													<button
														onClick={() =>
															updateQuantity(item.id, item.quantity + 1)
														}
														className='p-1 hover:bg-slate-100 rounded'>
														<Plus size={16} />
													</button>
													<button
														onClick={() => removeItem(item.id)}
														className='p-1 text-red-500 hover:bg-red-50 rounded'>
														<Trash2 size={16} />
													</button>
												</div>
											</div>
										))}

										<div className='pt-4'>
											<div className='flex justify-between text-lg font-semibold text-secondary'>
												<span>Total:</span>
												<span>${total.toFixed(2)}</span>
											</div>
										</div>

										{/* New customer info inputs */}
										<div className='mt-6 space-y-4'>
											<input
												type='text'
												placeholder='Your Name'
												className='w-full px-4 py-2 border rounded-md'
												value={name}
												onChange={(e) => setName(e.target.value)}
												required
											/>
											<input
												type='tel'
												placeholder='Your Phone Number'
												className='w-full px-4 py-2 border rounded-md'
												value={phoneNumber}
												onChange={(e) => setPhoneNumber(e.target.value)}
												required
											/>
										</div>

										<div className='flex items-center gap-3 mt-4'>
											<input
												type='checkbox'
												id='creditRequestedOrder'
												className='h-4 w-4 rounded border-gray-300'
												checked={creditRequested}
												onChange={(e) => setCreditRequested(e.target.checked)}
											/>
											<label
												htmlFor='creditRequestedOrder'
												className='text-sm font-medium'>
												I would like to apply for a credit facility.
											</label>
										</div>

										{/* Message display area */}
										{message && (
											<div
												className={`mt-4 p-3 rounded-md text-sm ${
													message.type === "success"
														? "bg-green-300 text-green-700"
														: "bg-red-300 text-red-700"
												}`}>
												{message.text}
											</div>
										)}

										<button
											onClick={handleSubmitOrder}
											className='w-full bg-primary text-black font-semibold py-3 rounded-md hover:bg-primary-dark transition-colors duration-300 mt-6'
											disabled={isLoading || orderItems.length === 0}>
											{isLoading ? "Submitting..." : "Submit Order Request"}
										</button>
									</div>
								)}
							</div>
						</div>
					</div>
				</div>
			</section>
		</div>
	);
};

export default OrderPage;
