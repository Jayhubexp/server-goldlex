import React from "react";
import { ScrollReveal } from "../components/animations/ScrollReveal";
import { Shield, Heart, Scale, Users, Target, Zap } from "lucide-react";
import PolicySection from "../components/home/PolicySection";

const PolicyPage: React.FC = () => {
	return (
		<div className='pt-20'>
			<PolicySection />
			<section className='bg-gradient-to-r from-primary to-primary-dark text-black py-20'>
				<div className='container mx-auto px-4 md:px-8'>
					<ScrollReveal>
						<div className='max-w-3xl mx-auto text-center'>
							<h1 className='text-4xl md:text-5xl font-bold mb-6'>
								Privacy Policy & Core Values
							</h1>
							<p className='text-xl opacity-90'>
								Our commitment to protecting your privacy and upholding our
								values in everything we do.
							</p>
						</div>
					</ScrollReveal>
				</div>
			</section>

			{/* Core Values Section */}
			<section className='py-20 bg-white'>
				<div className='container mx-auto px-4 md:px-8'>
					<ScrollReveal>
						<div className='text-center mb-16'>
							<h2 className='text-3xl md:text-4xl font-bold text-secondary mb-4'>
								Our Core Values
							</h2>
							<p className='text-slate-600 max-w-2xl mx-auto'>
								These principles guide our decisions and shape our company
								culture.
							</p>
						</div>
					</ScrollReveal>

					<div className='grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8'>
						{[
							{
								icon: <Heart className='text-primary\' size={40} />,
								title: "Customer First",
								description:
									"We prioritize our customers' needs and satisfaction above all else.",
							},
							{
								icon: <Shield className='text-primary' size={40} />,
								title: "Integrity",
								description:
									"We conduct business with honesty, transparency, and ethical practices.",
							},
							{
								icon: <Scale className='text-primary\' size={40} />,
								title: "Quality",
								description:
									"We maintain the highest standards in our products and services.",
							},
							{
								icon: <Users className='text-primary' size={40} />,
								title: "Teamwork",
								description:
									"We collaborate effectively to achieve common goals.",
							},
							{
								icon: <Target className='text-primary\' size={40} />,
								title: "Innovation",
								description:
									"We continuously improve and adapt to industry changes.",
							},
							{
								icon: <Zap className='text-primary' size={40} />,
								title: "Excellence",
								description: "We strive for excellence in everything we do.",
							},
						].map((value, index) => (
							<ScrollReveal key={index} delay={index * 100}>
								<div className='bg-white p-6 rounded-lg shadow-lg hover:shadow-xl transition-all duration-300'>
									<div className='mb-4'>{value.icon}</div>
									<h3 className='text-xl font-bold text-secondary mb-2'>
										{value.title}
									</h3>
									<p className='text-slate-600'>{value.description}</p>
								</div>
							</ScrollReveal>
						))}
					</div>
				</div>
			</section>

			{/* Privacy Policy Section */}
			<section className='py-20 bg-slate-50'>
				<div className='container mx-auto px-4 md:px-8'>
					<ScrollReveal>
						<div className='max-w-4xl mx-auto'>
							<h2 className='text-3xl font-bold text-secondary mb-8'>
								Privacy Policy
							</h2>

							<div className='space-y-8'>
								<div>
									<h3 className='text-xl font-semibold text-secondary mb-4'>
										Information Collection
									</h3>
									<p className='text-slate-600 mb-4'>
										We collect information that you provide directly to us,
										including:
									</p>
									<ul className='list-disc list-inside text-slate-600 space-y-2'>
										<li>Contact information (name, email, phone number)</li>
										<li>Business information</li>
										<li>Payment information</li>
										<li>Order history and preferences</li>
									</ul>
								</div>

								<div>
									<h3 className='text-xl font-semibold text-secondary mb-4'>
										Use of Information
									</h3>
									<p className='text-slate-600 mb-4'>
										We use the collected information to:
									</p>
									<ul className='list-disc list-inside text-slate-600 space-y-2'>
										<li>Process your orders and transactions</li>
										<li>
											Communicate with you about our products and services
										</li>
										<li>Improve our products and customer service</li>
										<li>
											Send you marketing communications (with your consent)
										</li>
									</ul>
								</div>

								<div>
									<h3 className='text-xl font-semibold text-secondary mb-4'>
										Data Security
									</h3>
									<p className='text-slate-600'>
										We implement appropriate technical and organizational
										measures to protect your personal information against
										unauthorized access, alteration, disclosure, or destruction.
										We regularly review and update our security practices to
										maintain the safety of your data.
									</p>
								</div>

								<div>
									<h3 className='text-xl font-semibold text-secondary mb-4'>
										Information Sharing
									</h3>
									<p className='text-slate-600'>
										We do not sell, trade, or otherwise transfer your personal
										information to outside parties. This does not include
										trusted third parties who assist us in operating our
										website, conducting our business, or servicing you, as long
										as these parties agree to keep this information
										confidential.
									</p>
								</div>

								<div>
									<h3 className='text-xl font-semibold text-secondary mb-4'>
										Your Rights
									</h3>
									<p className='text-slate-600 mb-4'>You have the right to:</p>
									<ul className='list-disc list-inside text-slate-600 space-y-2'>
										<li>Access your personal information</li>
										<li>Correct inaccurate information</li>
										<li>Request deletion of your information</li>
										<li>Opt-out of marketing communications</li>
									</ul>
								</div>

								<div>
									<h3 className='text-xl font-semibold text-secondary mb-4'>
										Contact Us
									</h3>
									<p className='text-slate-600'>
										If you have any questions about our Privacy Policy or Core
										Values, please contact us at
										goldlexautomerchandise@gmail.com or call us at
										+233204805119, +233500193936.
									</p>
								</div>
							</div>
						</div>
					</ScrollReveal>
				</div>
			</section>
		</div>
	);
};

export default PolicyPage;
